-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 28-11-2010 a las 14:40:16
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.2-1ubuntu4.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `coqus`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cake_sessions`
--

CREATE TABLE IF NOT EXISTS `cake_sessions` (
  `id` varchar(255) NOT NULL DEFAULT '',
  `data` text,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `cake_sessions`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rght` int(10) unsigned DEFAULT NULL,
  `name` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `description` text COLLATE utf8_spanish_ci NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `deleted_date` timestamp NULL DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent` (`parent_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `parent_id`, `lft`, `rght`, `name`, `description`, `created`, `modified`, `deleted_date`, `deleted`) VALUES
(1, NULL, 1, 2, '/', '', '2010-11-28 14:39:29', '2010-11-28 14:39:29', NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `codigo` int(11) DEFAULT NULL,
  `mail` varchar(110) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descuento_id` int(10) unsigned DEFAULT '0',
  `tipofactura` char(1) COLLATE utf8_spanish_ci DEFAULT NULL,
  `imprime_ticket` tinyint(1) DEFAULT '1',
  `nombre` varchar(110) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nrodocumento` varchar(11) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipodocumento` varchar(1) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo_documento_id` int(11) DEFAULT NULL,
  `domicilio` varchar(110) COLLATE utf8_spanish_ci DEFAULT NULL,
  `responsabilidad_iva` varchar(1) COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'ver el listado de posibilidades de CHARs para la responsabilidad del IVA, se pude ver en el codigo fuente, pero es casi un standar',
  `iva_responsabilidad_id` int(11) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=421 ;

--
-- Volcar la base de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `user_id`, `codigo`, `mail`, `telefono`, `descuento_id`, `tipofactura`, `imprime_ticket`, `nombre`, `nrodocumento`, `tipodocumento`, `tipo_documento_id`, `domicilio`, `responsabilidad_iva`, `iva_responsabilidad_id`, `created`, `modified`) VALUES
(20, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Sadar Amortiguadores', '30503252704', 'C', 1, '', 'I', 1, '2009-12-07 22:07:32', '2010-05-22 01:19:33'),
(3, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Wolff, Eduardo Alberto', '23081181659', 'C', 1, 'Cullen 5091', 'I', 1, '2009-11-15 20:59:15', '2010-06-23 22:41:29'),
(4, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Chaja SRL', '30710673248', 'L', 1, 'Vidal 2189 CABA', 'I', 1, '2009-11-15 21:07:27', '2009-12-12 05:24:25'),
(5, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Chinetti, Jorge', '20114581365', 'C', 1, 'Elordi 1073, Neuquen C.P 8300', 'I', 1, '2009-11-15 21:09:30', '2009-12-12 05:24:38'),
(121, 14, NULL, NULL, NULL, NULL, 'A', 1, 'RF. ELECTRONICS ARG. S.A.', '30710018711', NULL, 1, 'C.CALVO 2843', NULL, 1, '2010-03-06 21:43:19', '2010-03-06 21:43:19'),
(11, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Schiaffino Juan', '20242702205', 'C', 1, 'Hogiggins 250 (Ing. Maschwitz)', 'I', 1, '2009-11-22 13:53:10', '2009-12-12 05:24:56'),
(15, 7, NULL, NULL, NULL, NULL, 'A', 1, 'Roberto R. Di Lullo', '20083109093', 'C', 1, 'Terrada 3741   CABA', 'I', 1, '2009-11-30 13:25:23', '2009-12-12 05:25:11'),
(16, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Laboratorio Tablada SRL', '30658337730', 'C', 1, 'Suipacha 2321  Cordoba', 'I', 1, '2009-11-30 13:27:45', '2009-12-12 05:25:22'),
(18, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Cardinal Cooperativa de Credito Cons.', '30707594140', 'C', 1, '.', 'I', 1, '2009-12-05 21:28:42', '2009-12-12 05:25:35'),
(19, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'dohm srl', '30667104536', 'C', 1, 'Av Savio 336', 'I', 1, '2009-12-05 23:30:54', '2009-12-12 05:25:45'),
(22, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Full Stand S.A.', '30708344466', NULL, 1, 'Uruguay 651', NULL, 1, '2009-12-15 22:51:16', '2009-12-15 22:51:16'),
(26, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Pintureria Prestigio S.A.', '30577428618', NULL, 1, '.', NULL, 1, '2009-12-19 20:24:06', '2009-12-26 14:39:47'),
(27, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Tobias Carlos Miguel', '20076098507', NULL, 1, 'Salguero Jeronimo 2130', NULL, 1, '2009-12-20 13:46:36', '2009-12-20 13:46:36'),
(28, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Goldestein Alberto Ernesto', '20078378841', NULL, 1, 'Rosales 58 Ramos Mejia', NULL, 1, '2009-12-20 14:24:06', '2009-12-20 14:24:06'),
(29, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Manuel Ongaro', '23163064499', NULL, 1, '', NULL, 1, '2009-12-20 22:11:55', '2009-12-20 22:11:55'),
(30, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Prodismo SRL', '33547788589', NULL, 1, 'Av Japon 2230 Cordoba', NULL, 1, '2009-12-23 13:43:54', '2009-12-23 13:43:54'),
(31, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Favereau S.A. De tasaciones', '30695587445', NULL, 1, '25 de Mayo 252 7 piso', NULL, 1, '2009-12-23 22:33:09', '2009-12-23 22:33:09'),
(32, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Sol de imagen SRL', '30711114153', NULL, 1, '', NULL, 1, '2009-12-24 12:41:02', '2009-12-24 12:41:02'),
(33, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Magic Star SA', '30693182960', NULL, 1, '', NULL, 1, '2009-12-25 22:03:25', '2009-12-25 22:03:25'),
(34, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Cergen SRL', '30629122806', NULL, 1, '-', NULL, 1, '2009-12-25 22:50:55', '2009-12-25 22:50:55'),
(35, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Horacio Iturrioz', '20134807351', NULL, 1, 'Sarmiento 995, Esquel, Chubut', NULL, 1, '2009-12-26 13:29:11', '2009-12-26 13:29:11'),
(37, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Adamini Bautista ', '20076837695', NULL, 1, 'Los Toldos Buenos Aires', NULL, 1, '2010-01-01 22:03:28', '2010-01-01 22:03:28'),
(39, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Grupo Gas SRL', '30645881008', NULL, 1, 'Avda Independencia 3933', NULL, 1, '2010-01-02 22:47:12', '2010-01-02 22:47:12'),
(40, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Mariano Cantaluppi Yrigoyen', '20168446234', NULL, 1, 'R PeÃ±a 3259 Martinez', NULL, 1, '2010-01-03 01:01:54', '2010-01-03 01:04:27'),
(41, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Omar Enrique Greppi', '20132559431', NULL, 1, 'Tucuman 1007 9B Rosario', NULL, 1, '2010-01-03 21:52:45', '2010-01-03 21:52:45'),
(42, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Eduardo Ruesta', '20116070619', NULL, 1, 'Calle 56 421 La Plata', NULL, 1, '2010-01-03 23:10:33', '2010-01-03 23:10:33'),
(43, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Abril Med SA', '30707634389', NULL, 1, '.', NULL, 1, '2010-01-05 14:00:33', '2010-01-05 15:13:59'),
(44, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Gerosa Alfredo Luis ', '20073776938', NULL, 1, 'Mitre Emilio 241 piso 3 dpto 5, CABA', NULL, 1, '2010-01-06 21:39:20', '2010-01-06 21:39:20'),
(45, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Nestle Argentina SA', '30546764040', NULL, 1, 'Del Libertador 1855 Vic Lopez Bs As', NULL, 1, '2010-01-07 15:11:43', '2010-01-07 15:21:24'),
(46, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Bellesi SA', '30502161691', NULL, 1, 'Boedo 2552, Villa Adelina, BS AS', NULL, 1, '2010-01-09 22:37:58', '2010-01-09 22:37:58'),
(47, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'JSM SRL', '30709726230', NULL, 1, 'Orono 500, Rosario', NULL, 1, '2010-01-10 00:28:44', '2010-01-10 00:28:44'),
(48, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Humberto F. Bruni', '20046476620', NULL, 1, '.', NULL, 1, '2010-01-10 01:05:55', '2010-01-10 01:05:55'),
(49, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Starseg SRL', '30651824938', NULL, 1, 'Granaderos 352 CABA', NULL, 1, '2010-01-10 21:27:24', '2010-01-10 21:27:24'),
(50, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Villano Julio', '20138902928', NULL, 1, '25 de Mayo 578 CABA', NULL, 1, '2010-01-10 22:13:00', '2010-01-10 22:14:14'),
(51, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Search Organizacion de seguridad SA', '30549486513', NULL, 1, '', NULL, 1, '2010-01-10 22:42:19', '2010-01-10 22:42:19'),
(52, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Transportes el cholo SA', '30658183636', NULL, 1, 'Bueras 2901', NULL, 1, '2010-01-11 00:22:29', '2010-01-11 00:22:29'),
(53, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'LD Consultora S.A.', '30710931964', NULL, 1, 'Azcuenaga 512 Lujan de Cuyo Mza.', NULL, 1, '2010-01-11 23:06:23', '2010-01-11 23:06:23'),
(55, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'BAYTON S.E.S.A', '30651350537', NULL, 1, 'SARMIENTO 1113', NULL, 1, '2010-01-14 14:42:32', '2010-01-14 14:42:32'),
(56, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Gabriel Fernandez', '20284015941', NULL, 1, 'Da Silva 663 Bell Ville CBA', NULL, 1, '2010-01-15 00:10:15', '2010-01-15 00:10:15'),
(57, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'LA AGRICOLA S.A', '30517874910', NULL, 1, 'Ruta 33 km 7.5 Maipu Mendoza', NULL, 1, '2010-01-15 00:29:07', '2010-01-15 00:29:07'),
(58, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Armeria Las Colonias S.A.', '30540938322', NULL, 1, 'E Zeballos 3708 Sta Fe', NULL, 1, '2010-01-15 21:38:23', '2010-01-15 21:38:23'),
(59, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Quantun Finanzas SA', '30711022666', NULL, 1, 'Moreau de Justo Av 1150 piso 4 CABA', NULL, 1, '2010-01-15 23:40:59', '2010-01-15 23:40:59'),
(60, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Penna Cereales SRL', '30708228474', NULL, 1, 'Cordoba 1360 piso 1 Santa Fe', NULL, 1, '2010-01-17 21:24:17', '2010-01-17 21:24:17'),
(61, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Establecimiento Grafico Impresores SA', '30500439617', NULL, 1, 'Quesada 2422 Piso 7 dpto A CABA', NULL, 1, '2010-01-17 23:00:39', '2010-01-17 23:00:39'),
(62, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Codetech SRL', '30708658282', NULL, 1, 'Oribe 2338 BsAs', NULL, 1, '2010-01-18 00:25:39', '2010-01-18 00:25:39'),
(63, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Gomez Walter Pablo', '20218904085', NULL, 1, 'Fray Luis Beltran 335', NULL, 1, '2010-01-18 21:09:22', '2010-01-18 21:09:22'),
(64, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Gustavo Daniel Lombardo', '20175058126', NULL, 1, 'Zabala 2621 CABA', NULL, 1, '2010-01-21 21:30:52', '2010-01-21 21:30:52'),
(65, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Chardin SRL', '30708054255', NULL, 1, 'Luis Maria Campos 1151 pb 10', NULL, 1, '2010-01-23 22:14:06', '2010-01-23 22:14:06'),
(66, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Tavigosa S.A.', '30710066473', NULL, 1, 'M. Brin 2655 Lanus', NULL, 1, '2010-01-24 00:05:07', '2010-01-24 00:05:07'),
(67, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'David Hollywood', '20932930774', NULL, 1, '', NULL, 1, '2010-01-24 22:57:15', '2010-01-24 22:57:15'),
(68, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Civiles Management SRL', '30708919019', NULL, 1, 'Darwin 1154', NULL, 1, '2010-01-25 00:29:22', '2010-01-25 00:30:02'),
(69, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Santiago Condomi Alcorda ', '20102022859', NULL, 1, 'Av Libertador 2609 5 B', NULL, 1, '2010-01-26 00:19:03', '2010-01-26 00:19:03'),
(70, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Sisdam S.A.', '30652162041', NULL, 1, 'Rojas Ricardo Dr. 401 Piso 10', NULL, 1, '2010-01-26 00:34:01', '2010-01-26 00:34:01'),
(71, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Vanjusil SA', '30710034350', NULL, 1, '25 de mayo 244 piso 3 CABA', NULL, 1, '2010-01-26 23:23:39', '2010-01-26 23:23:39'),
(72, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Navarro Irma Graciela', '27112966310', NULL, 1, 'Ardiles 132 Villa Mercedes San Luis', NULL, 1, '2010-01-26 23:25:23', '2010-01-26 23:25:23'),
(73, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Cigliutti Guerini SACIFIYA', '30636741120', NULL, 1, 'Bonorino Cnel 299 CABA', NULL, 1, '2010-01-26 23:27:58', '2010-01-26 23:27:58'),
(74, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Zipilivan Alejandro', '20125148833', NULL, 1, 'Bogota 3922', NULL, 1, '2010-01-27 23:12:53', '2010-01-27 23:12:53'),
(75, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Distrizub SA', '30627598099', NULL, 1, 'Lavalle 940 Maipu Buenos Aires', NULL, 1, '2010-01-28 14:01:11', '2010-01-28 14:01:11'),
(76, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Liqsa Sacifieya', '30639723603', NULL, 1, 'Estanislao del Campo 906', NULL, 1, '2010-01-28 23:44:51', '2010-01-28 23:44:51'),
(77, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Mario Peiro SA', '30645598039', NULL, 1, 'J B Justo 375 San Pedro', NULL, 1, '2010-01-28 23:54:09', '2010-01-28 23:54:09'),
(78, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Tornquist G M y Justo', '30707747532', NULL, 1, 'Av Cabildo 1708 5 B CABA', NULL, 1, '2010-01-29 00:04:50', '2010-01-29 00:04:50'),
(79, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Prointex SRL', '30614738274', NULL, 1, 'Ituzaingo 625 Bernal BsAs', NULL, 1, '2010-01-29 01:16:54', '2010-01-29 01:16:54'),
(80, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Activos compartidos SA', '30710283245', NULL, 1, 'Gordillo Timoteo 5697', NULL, 1, '2010-01-29 21:24:51', '2010-01-29 21:24:51'),
(81, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Graciela Juarez SRL', '33696868099', NULL, 1, 'Tucuman 1446 CABA', NULL, 1, '2010-01-29 21:26:21', '2010-01-29 21:26:21'),
(82, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Safeguard SRL', '30643138839', NULL, 1, 'Capdevila 2851 CABA', NULL, 1, '2010-01-29 23:00:35', '2010-01-29 23:00:35'),
(83, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Andres Gabriel Andres Mario Andres Gustavo Sociedad de Hechoo', '30665864169', NULL, 1, 'Nueve de Julio 247 El Triunfo', NULL, 1, '2010-01-30 01:05:31', '2010-01-30 01:05:31'),
(84, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Albaca Ricardo', '20114768937', NULL, 1, 'Corrientes 947 San Miguel de Tucuman ', NULL, 1, '2010-01-30 01:10:49', '2010-01-30 01:10:49'),
(85, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Evangelista Osmar Jose', '20049665750', NULL, 1, 'Mitre 119 Salto ', NULL, 1, '2010-01-30 14:32:25', '2010-01-30 14:32:25'),
(86, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Pablo Sergio Galeano', '20202269797', NULL, 1, 'Austria 2173 piso 5', NULL, 1, '2010-01-31 00:38:29', '2010-01-31 00:38:29'),
(87, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Prestaciones Bangka S.A.', '33710871669', NULL, 1, 'Romulo Naon 395', NULL, 1, '2010-01-31 01:08:04', '2010-01-31 01:08:04'),
(88, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Areas Energeticas S.R.L.', '30708947489', NULL, 1, 'Ayacucho 3625 Rosario', NULL, 1, '2010-01-31 23:16:16', '2010-01-31 23:16:16'),
(89, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Porfiri Alejandro Oscar ', '20205148559', NULL, 1, 'Rivadavia 1467', NULL, 1, '2010-02-01 21:47:40', '2010-02-01 21:47:40'),
(90, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Pablo Andres Libralesso', '20274020475', NULL, 1, 'Funchs 618 Santa Cruz', NULL, 1, '2010-02-01 22:30:54', '2010-02-01 22:30:54'),
(91, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Bebidas del mar SA', '30708857285', NULL, 1, '', NULL, 1, '2010-02-05 11:13:20', '2010-02-05 11:13:20'),
(92, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Aco Color SA', '30695574688', NULL, 1, 'Calle 139 m1890 LA PLATA', NULL, 1, '2010-02-07 23:25:00', '2010-02-07 23:25:00'),
(93, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Giordana Norberto Juan', '20060633739', NULL, 1, 'Loreto Virrey 2548 CABA', NULL, 1, '2010-02-08 22:14:01', '2010-02-08 22:14:01'),
(94, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Chain Guillermo', '20250769912', NULL, 1, '', NULL, 1, '2010-02-09 00:11:28', '2010-02-09 00:11:28'),
(95, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Bingo de la Pcia SA', '30641821426', NULL, 1, 'Calle 2555, San Clemente del Tuyu', NULL, 1, '2010-02-10 21:33:29', '2010-02-10 21:33:29'),
(96, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Jim S.A.', '30674855520', NULL, 1, '', NULL, 1, '2010-02-11 00:24:49', '2010-02-11 00:24:49'),
(97, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Hector Raggio', '20040392891', NULL, 1, '', NULL, 1, '2010-02-11 22:45:16', '2010-02-11 22:45:16'),
(98, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Brokers Interactive SA', '33708252609', NULL, 1, 'Rivadavia 256 Mendoza', NULL, 1, '2010-02-11 23:40:15', '2010-02-11 23:40:15'),
(99, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Castell s SA', '33574619519', NULL, 1, 'Rivadavia 5231 CABA', NULL, 1, '2010-02-12 00:18:36', '2010-02-12 00:18:36'),
(100, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Manrique Antonio', '20121876966', NULL, 1, '', NULL, 1, '2010-02-13 14:14:37', '2010-02-13 14:14:37'),
(101, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'R.N CONFECCIONES S.A', '30693356888', NULL, 1, 'Merced 640  (Pergamino)', NULL, 1, '2010-02-15 01:34:50', '2010-02-15 01:34:50'),
(102, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Diego Josset S.H.', '30709868426', NULL, 1, '', NULL, 1, '2010-02-18 23:24:40', '2010-02-18 23:24:40'),
(103, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Vivero del Sol Y Cy Clamen SRL', '30707258809', NULL, 1, 'Mitre 359 San Nicolas', NULL, 1, '2010-02-18 23:26:05', '2010-02-18 23:26:05'),
(104, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Gutierrez Roberto', '20045814247', NULL, 1, '', NULL, 1, '2010-02-19 22:01:45', '2010-02-19 22:01:45'),
(105, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Ruben Galaretto', '20061788108', NULL, 1, '', NULL, 1, '2010-02-20 14:34:48', '2010-02-20 14:34:48'),
(106, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Pagoda SA', '30676870403', NULL, 1, '', NULL, 1, '2010-02-20 15:16:31', '2010-02-20 15:16:31'),
(107, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Venticinque Adamo', '20228245691', NULL, 1, 'El Salvador 4975', NULL, 1, '2010-02-20 22:11:30', '2010-02-20 22:11:30'),
(108, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Nexo Servicios Postales SRL', '30580951178', NULL, 1, 'Potosi 4431 CABA', NULL, 1, '2010-02-20 23:04:48', '2010-02-20 23:04:48'),
(109, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Claudio Montaldo y asoc SRL', '30620539259', NULL, 1, 'sarmiento 789, gral madariaga', NULL, 1, '2010-02-24 00:24:12', '2010-02-24 00:24:12'),
(110, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Norberto Garcia ', '20129653125', NULL, 1, 'Av Director 662 ', NULL, 1, '2010-02-24 21:55:44', '2010-02-24 21:55:44'),
(111, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Benito Aldazabal ', '20046771754', NULL, 1, 'Beruti 3825 Capital', NULL, 1, '2010-02-24 22:39:26', '2010-02-24 22:39:26'),
(112, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Formato S.A.', '30635542434', NULL, 1, 'Pastor Obligado 2053 - San Isidro', NULL, 1, '2010-02-25 14:36:00', '2010-02-25 14:36:00'),
(113, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Fonres S.A.', '30710419600', NULL, 1, '', NULL, 1, '2010-02-25 22:20:21', '2010-02-25 22:20:21'),
(114, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Adrian Lattazio', '30710854501', NULL, 1, '', NULL, 1, '2010-02-25 23:05:03', '2010-02-25 23:05:03'),
(115, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Fernando Miguel Suarez', '20133855824', NULL, 1, 'Moreno 442 Capital Federal ', NULL, 1, '2010-02-27 22:48:02', '2010-02-27 22:48:02'),
(116, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Balboa Pred.Publ. SRL', '30661185542', NULL, 1, 'Av San Martin 2708 - Florida', NULL, 1, '2010-03-02 21:09:51', '2010-03-02 21:09:51'),
(117, 6, NULL, NULL, NULL, NULL, 'A', 1, 'JORGE CUBURU', '20077293133', NULL, 1, 'Mitre 430 - Chillar', NULL, 1, '2010-03-05 21:10:29', '2010-03-05 21:10:29'),
(118, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'RENATO LUCANTO', '20137411904', NULL, 1, '', NULL, 1, '2010-03-05 23:39:55', '2010-03-05 23:39:55'),
(122, 14, NULL, NULL, NULL, NULL, 'A', 1, 'SEBRE SRL', '30602827611', NULL, 1, 'J.B.JUSTO 181 - (2900) SAN NICOLAS', NULL, 1, '2010-03-07 00:52:43', '2010-03-07 00:52:43'),
(123, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Tube Center S.A', '30709968277', NULL, 1, 'B de Astrada 2742', NULL, 1, '2010-03-10 23:04:55', '2010-03-10 23:04:55'),
(124, 14, NULL, NULL, NULL, NULL, 'A', 1, 'CELIA BROSIO', '27108235344', NULL, 1, 'Beruti 2902 - Cap.', NULL, 1, '2010-03-12 21:15:31', '2010-03-12 21:15:31'),
(125, 14, NULL, NULL, NULL, NULL, 'A', 1, 'FORMENTO HECTOR R.', '20082527711', NULL, 1, 'Aguado 844 - Gral. Pacheco - 1617 - Bs.As.', NULL, 1, '2010-03-12 23:28:43', '2010-03-12 23:28:43'),
(126, 14, NULL, NULL, NULL, NULL, 'A', 1, 'OFFICE MANAGEMENT SRL', '30695113982', NULL, 1, 'Avellaneda 2542, Olivos, Bs.As.', NULL, 1, '2010-03-13 22:50:01', '2010-03-13 22:50:01'),
(127, 7, NULL, NULL, NULL, NULL, 'A', 1, 'Maximiliano Barreiro', '20044399734', NULL, 1, 'Terrero 536 San Isidro', NULL, 1, '2010-03-23 15:09:50', '2010-03-23 15:09:50'),
(128, 7, NULL, NULL, NULL, NULL, 'A', 1, 'DI LULLO  ROBERTO', '20083109093', NULL, 1, 'TERRADA 3741 - CAP FED', NULL, 1, '2010-03-30 22:05:17', '2010-03-30 22:05:17'),
(129, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Euroal S.A. ', '33708966059', NULL, 1, 'Uruguay 654 ', NULL, 1, '2010-04-02 23:12:05', '2010-04-02 23:12:05'),
(130, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Franco Quimica S.A.', '30641294752', NULL, 1, '', NULL, 1, '2010-04-03 01:05:58', '2010-04-03 01:05:58'),
(131, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Gravent S.A.', '30633217803', NULL, 1, 'Cosquin 4259 Capital Federal', NULL, 1, '2010-04-03 15:46:26', '2010-04-03 15:46:26'),
(132, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Dynsis S.A.', '30711252335', NULL, 1, 'Espinosa 1533 Capital Federal', NULL, 1, '2010-04-03 22:10:32', '2010-04-03 22:10:32'),
(133, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Industrial Patagonia S.A.', '30708970162', NULL, 1, 'Av 1815 N 8189 Rosario', NULL, 1, '2010-04-03 22:30:53', '2010-04-03 22:30:53'),
(134, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Galante D Antonio SA', '30550132466', NULL, 1, 'parana 230 piso 09 capital federal', NULL, 1, '2010-04-03 23:42:47', '2010-04-03 23:42:47'),
(135, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Susco Juan ', '20272300268', NULL, 1, 'Alvear 720 ', NULL, 1, '2010-04-03 23:55:56', '2010-04-03 23:55:56'),
(136, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Mariano Colomer', '20247342908', NULL, 1, 'Paraguay 4661 Capital Federal', NULL, 1, '2010-04-04 14:18:39', '2010-04-04 14:18:39'),
(137, 2, NULL, NULL, NULL, NULL, 'A', 1, 'PYPSA S.A.', '33505819409', NULL, 1, '118 nÂº 1441 _ LA PLATA', NULL, 1, '2010-04-25 21:29:33', '2010-04-25 21:29:33'),
(138, 2, NULL, NULL, NULL, NULL, 'A', 1, 'PYPSA S.A.', '33505819409', NULL, 1, '118 nÂº 1441 _ LA PLATA', NULL, 1, '2010-04-25 21:30:04', '2010-04-25 21:30:04'),
(139, 2, NULL, NULL, NULL, NULL, 'A', 1, 'LEONARDO  FONTANA', '20286591265', NULL, 1, 'PRINGLES 155', NULL, 1, '2010-05-01 20:55:08', '2010-05-01 20:55:08'),
(140, 8, NULL, NULL, NULL, NULL, 'A', 1, 'Renda Jorge A.', '20117704719', NULL, 1, 'Dorrego 1515 Martinez', NULL, 1, '2010-05-02 15:12:25', '2010-05-02 15:12:25'),
(141, 7, NULL, NULL, NULL, NULL, 'A', 1, 'PHARMA GBG S.A.', '30708559063', NULL, 1, 'Roque Perez 2537 C.A.B.A.', NULL, 1, '2010-05-12 21:22:17', '2010-05-12 21:22:17'),
(142, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Epise SRL', '30710039654', NULL, 1, 'Maipu 464', NULL, 1, '2010-05-14 14:07:19', '2010-05-14 14:07:19'),
(143, 7, NULL, NULL, NULL, NULL, 'A', 1, 'Sutter Argentina S.A.', '30688979761', NULL, 1, 'Cerrito 1294 Piso 17 Buenos Aires', NULL, 1, '2010-05-19 22:39:26', '2010-05-19 22:39:26'),
(144, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'CARILO INVEST S.A.', '30708356324', NULL, 1, 'Libertad 6056 Mar del plata', NULL, 1, '2010-05-23 01:05:49', '2010-05-23 01:05:49'),
(145, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Padirac SA', '30707265643', NULL, 1, 'Alsina 1535 Piso 5 CABA', NULL, 1, '2010-05-23 15:35:05', '2010-05-23 15:35:05'),
(146, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Automoviles San Jorge S.A.', '30684046116', NULL, 1, 'Av La Plata 1635', NULL, 1, '2010-05-31 22:05:10', '2010-05-31 22:05:10'),
(147, 28, NULL, NULL, NULL, NULL, 'A', 1, 'Neumaticos Mar del Plata S.A.', '33610077019', NULL, 1, 'Independencia 4045', NULL, 1, '2010-06-02 13:40:12', '2010-06-02 13:40:12'),
(148, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Amacom S.R.L.', '33684313709', NULL, 1, '', NULL, 1, '2010-06-04 23:52:05', '2010-06-04 23:52:05'),
(149, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Bec Consulting Group S.A.', '30696845995', NULL, 1, 'Lavalle 534 Piso 5', NULL, 1, '2010-06-05 01:15:21', '2010-06-05 01:15:21'),
(150, 1, NULL, NULL, NULL, NULL, 'A', 1, 'MASSINI RODOLFO NESTOR', '20076061239', NULL, 1, 'TERRERO 571', NULL, 1, '2010-06-23 22:43:07', '2010-06-23 22:43:07'),
(151, 28, NULL, NULL, NULL, NULL, 'A', 1, 'Yamaha Motor Argentina S.A.', '30687234754', NULL, 1, 'Av. Pte. Peron 8370 Ituzaingo', NULL, 1, '2010-06-30 20:58:24', '2010-06-30 20:58:24'),
(152, 28, NULL, NULL, NULL, NULL, 'A', 1, 'Cesari Rino Alberto', '20120473132', NULL, 1, '', NULL, 1, '2010-06-30 22:20:26', '2010-06-30 22:20:26'),
(153, 28, NULL, NULL, NULL, NULL, 'A', 1, 'Procobra S.A. ', '30710772947', NULL, 1, 'Av. Fleming 4246 San Martin', NULL, 1, '2010-07-02 14:10:29', '2010-07-02 14:13:35'),
(154, 28, NULL, NULL, NULL, NULL, 'A', 1, 'SKS Sudamericana S.A.', '30711129479', NULL, 1, 'Vuelta de Obligado 1947 3ro. B. Belgrano CABA.', NULL, 1, '2010-07-02 14:45:47', '2010-07-02 14:45:47'),
(155, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Greppi Omar Enrique', '20132559431', NULL, 1, 'tucuman 1007 9 b  Rosario', NULL, 1, '2010-07-04 20:42:31', '2010-07-04 20:42:31'),
(156, 28, NULL, NULL, NULL, NULL, 'A', 1, 'Nicolas Diego Vazquez', '20260192362', NULL, 1, 'Italia 5043 Benavidez', NULL, 1, '2010-07-07 15:42:22', '2010-07-07 15:42:22'),
(157, 28, NULL, NULL, NULL, NULL, 'A', 1, 'Cabletech Argentina S.A.', '30711230188', NULL, 1, '', NULL, 1, '2010-07-08 14:42:19', '2010-07-08 14:42:19'),
(158, 28, NULL, NULL, NULL, NULL, 'A', 1, 'Prado Jorge Luis', '20200294867', NULL, 1, 'Porcel de Peralta 907 Cap. Fed.', NULL, 1, '2010-07-09 15:08:05', '2010-07-09 15:08:05'),
(159, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Biotay S.A.', '30604993853', NULL, 1, 'Tucucman 829 5 P Capital Federal', NULL, 1, '2010-07-11 12:18:41', '2010-07-11 12:18:41'),
(160, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Setentatreinta S.A.', '30708696516', NULL, 1, 'Salguero 1450  CP 1177', NULL, 1, '2010-07-19 22:38:06', '2010-07-19 22:38:06'),
(161, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Martin Constancia Evelina', '27065456295', NULL, 1, 'Cura Allievi 171 Bologne ', NULL, 1, '2010-07-23 20:03:44', '2010-07-23 20:03:44'),
(162, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Szraiber Daniel Leonardo', '20181299445', NULL, 1, '9 de Julio 103  Moron ', NULL, 1, '2010-07-23 22:43:17', '2010-07-23 22:43:17'),
(163, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Aridos de Campana S.A.', '30682802797', NULL, 1, 'Tucuman 834 P 5 Dpto 1', NULL, 1, '2010-07-23 23:14:29', '2010-07-23 23:14:29'),
(164, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Panas SRL', '30703106524', NULL, 1, 'Lacroze 7155 1piso', NULL, 1, '2010-07-24 14:55:44', '2010-07-24 14:55:44'),
(165, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Holland Cross S.A.', '30707441921', NULL, 1, 'Esmeralda 886 p4 dto g ', NULL, 1, '2010-07-31 20:57:51', '2010-07-31 20:57:51'),
(166, 28, NULL, NULL, NULL, NULL, 'A', 1, 'Sanofi Aventis S.A.', '30501445416', NULL, 1, 'Tomkinson 2054 San Isidro', NULL, 1, '2010-08-04 17:27:14', '2010-08-04 17:27:14'),
(167, 28, NULL, NULL, NULL, NULL, 'A', 1, 'Scherman Adrian', '20176112647', NULL, 1, 'Artigas 2045 Cap.', NULL, 1, '2010-08-10 15:10:48', '2010-08-10 15:10:48'),
(168, 28, NULL, NULL, NULL, NULL, 'A', 1, 'Stanza Group S.R.L.', '30710753586', NULL, 1, 'Silvio L. Ruggeri 2785 C.F.', NULL, 1, '2010-08-10 23:30:22', '2010-08-10 23:30:22'),
(169, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Gianina Guillermo Jorge', '20110278757', NULL, 1, 'Tres sargento 463 p2 dto a ', NULL, 1, '2010-08-15 01:50:43', '2010-08-15 01:50:43'),
(170, NULL, NULL, NULL, NULL, NULL, 'A', 1, 'Postiglione Marcela', '27204415620', NULL, 1, 'Av. VICTOR HUGO nÂº 1232', NULL, 1, '2010-08-19 19:39:06', '2010-08-19 19:39:06'),
(172, NULL, NULL, '', '', NULL, 'A', 1, 'Redguard S.A.', '30708627638', NULL, 1, '', NULL, 1, '2010-08-29 14:11:53', '2010-08-29 14:11:53'),
(257, NULL, NULL, '', '', NULL, 'A', 1, 'Tinta Marcos Augusto', '20200548397', NULL, 1, 'Av. Santa Fe 2966', NULL, 1, '2010-09-04 22:17:54', '2010-09-04 22:17:54'),
(407, NULL, NULL, NULL, NULL, 0, 'A', 1, 'GC SEGURIDAD SA', '30711266395', NULL, 1, NULL, NULL, 1, '2010-11-21 22:30:48', '2010-11-21 22:30:48'),
(406, NULL, NULL, NULL, NULL, 0, 'A', 1, 'DI MAURO JOSE ORLANDO', '20045816444', NULL, 1, NULL, NULL, 1, '2010-11-21 21:39:10', '2010-11-21 21:39:10'),
(405, NULL, NULL, NULL, NULL, 0, 'A', 1, 'FELIPE Y CARLOS GRACIANO S A', '30629829802', NULL, 1, NULL, NULL, 1, '2010-11-21 14:12:46', '2010-11-21 14:12:46'),
(403, NULL, NULL, NULL, NULL, 0, 'A', 1, 'JPA S.A.', '30707348336', NULL, 1, NULL, NULL, 1, '2010-11-20 23:29:33', '2010-11-20 23:29:33'),
(404, NULL, NULL, NULL, NULL, 0, 'A', 1, 'STAFFOLANI PABLO MARTIN', '20234631862', NULL, 1, NULL, NULL, 1, '2010-11-20 23:48:52', '2010-11-20 23:48:52'),
(410, NULL, NULL, NULL, NULL, 0, 'A', 1, 'INGENIERIA ELECTRICA S R L ', '30580463998', NULL, 1, NULL, NULL, 1, '2010-11-24 21:35:24', '2010-11-24 21:35:24'),
(402, NULL, NULL, NULL, NULL, 0, 'A', 1, 'LIMA EDGARDO LUIS', '20083507900', NULL, 1, NULL, NULL, 1, '2010-11-20 22:04:53', '2010-11-20 22:04:53'),
(400, NULL, NULL, NULL, NULL, 0, 'A', 1, 'CORCOM S.A.', '30707443959', NULL, 1, NULL, NULL, 1, '2010-11-20 21:05:19', '2010-11-20 21:05:19'),
(399, NULL, NULL, NULL, NULL, 0, 'A', 1, 'SPA CATALINA S A ', '30690753460', NULL, 1, NULL, NULL, 1, '2010-11-20 14:54:26', '2010-11-20 14:54:26'),
(397, NULL, NULL, NULL, NULL, 0, 'A', 1, 'MIRAFLORES S A ', '', NULL, 1, NULL, NULL, 1, '2010-11-19 23:47:32', '2010-11-19 23:47:32'),
(398, NULL, NULL, NULL, NULL, 0, 'A', 1, 'MIRAFLORES', '30577350813', NULL, 1, NULL, NULL, 1, '2010-11-19 23:48:31', '2010-11-19 23:48:31'),
(396, NULL, NULL, NULL, NULL, 0, 'A', 1, 'GLOBALPAK S R L', '30708815523', NULL, 1, NULL, NULL, 1, '2010-11-19 15:21:08', '2010-11-19 15:21:08'),
(395, NULL, NULL, NULL, NULL, 0, 'A', 1, 'NIVRO S A ', '30708640634', NULL, 1, NULL, NULL, 1, '2010-11-19 13:51:01', '2010-11-19 13:51:01'),
(394, NULL, NULL, NULL, NULL, 0, 'A', 1, 'PARK SERVICE S R L ', '30647871875', NULL, 1, NULL, NULL, 1, '2010-11-18 23:04:04', '2010-11-18 23:04:04'),
(393, NULL, NULL, NULL, NULL, 0, 'A', 1, 'REGGIARDO CARLOS OMAR ', '20226574779', NULL, 1, NULL, NULL, 1, '2010-11-18 14:24:17', '2010-11-18 14:24:17'),
(391, NULL, NULL, NULL, NULL, 0, 'A', 1, 'B', '', NULL, 1, NULL, NULL, 1, '2010-11-17 22:05:18', '2010-11-17 22:05:18'),
(392, NULL, NULL, NULL, NULL, 0, 'A', 1, 'VALDEMOROS GLADIS', '27134951058', NULL, 1, NULL, NULL, 1, '2010-11-17 22:06:09', '2010-11-17 22:06:09'),
(390, NULL, NULL, NULL, NULL, 0, 'A', 1, 'VALDEMOROS GLADIS', '', NULL, 1, NULL, NULL, 1, '2010-11-17 22:04:55', '2010-11-17 22:04:55'),
(389, NULL, NULL, NULL, NULL, 0, 'A', 1, 'benito AldaZabal', '20046771754', NULL, 1, NULL, NULL, 1, '2010-11-16 23:06:31', '2010-11-16 23:06:31'),
(387, NULL, NULL, NULL, NULL, 0, 'A', 1, 'benito AldaZabal', '', NULL, 1, NULL, NULL, 1, '2010-11-16 23:04:39', '2010-11-16 23:04:39'),
(388, NULL, NULL, NULL, NULL, 0, 'A', 1, 'benito AldaZabal', '20046771754', NULL, 1, NULL, NULL, 1, '2010-11-16 23:05:30', '2010-11-16 23:05:30'),
(386, NULL, NULL, NULL, NULL, 0, 'A', 1, 'B J Alda Zabal', '', NULL, 1, NULL, NULL, 1, '2010-11-16 23:04:20', '2010-11-16 23:04:20'),
(385, NULL, NULL, NULL, NULL, 0, 'A', 1, 'benito AldaZabal', '20046771754', NULL, 1, NULL, NULL, 1, '2010-11-16 23:00:11', '2010-11-16 23:00:11'),
(384, NULL, NULL, NULL, NULL, 0, 'A', 1, 'benito AldaZabal', '20046771754', NULL, 1, NULL, NULL, 1, '2010-11-16 22:52:09', '2010-11-16 22:52:09'),
(383, NULL, NULL, NULL, NULL, 0, 'A', 1, 'PROGRES S A ', '30663306932', NULL, 1, NULL, NULL, 1, '2010-11-15 21:27:15', '2010-11-15 21:27:15'),
(382, NULL, NULL, NULL, NULL, 0, 'A', 1, 'M D Q LE SPORT S A ', '30708157054', NULL, 1, NULL, NULL, 1, '2010-11-14 23:06:23', '2010-11-14 23:06:23'),
(381, NULL, NULL, NULL, NULL, 0, 'A', 1, 'M D Q ', '30708157054', NULL, 1, NULL, NULL, 1, '2010-11-14 23:04:20', '2010-11-14 23:04:20'),
(379, NULL, NULL, NULL, NULL, 0, 'A', 1, 'ETIKA S R L ', '', NULL, 1, NULL, NULL, 1, '2010-11-14 22:43:24', '2010-11-14 22:43:24'),
(380, NULL, NULL, NULL, NULL, 0, 'A', 1, 'ETIKA S R L ', '30694280893', NULL, 1, NULL, NULL, 1, '2010-11-14 22:44:33', '2010-11-14 22:44:33'),
(378, NULL, NULL, NULL, NULL, 0, 'A', 1, 'VOLONTE RUBEN MARIO', '20165027060', NULL, 1, NULL, NULL, 1, '2010-11-14 22:08:16', '2010-11-14 22:08:16'),
(377, NULL, NULL, NULL, NULL, 0, 'A', 1, 'Arijo, Guillermo', '20085858050', NULL, 1, NULL, NULL, 1, '2010-11-13 21:15:17', '2010-11-13 21:15:17'),
(376, NULL, NULL, NULL, NULL, 0, 'A', 1, 'BACHILLER JUAN CARLOS', '20082661841', NULL, 1, NULL, NULL, 1, '2010-11-13 14:58:19', '2010-11-13 14:58:19'),
(375, NULL, NULL, NULL, NULL, 0, 'A', 1, 'CONDOMI ALCORTA SANTIAGO', '20102022859', NULL, 1, NULL, NULL, 1, '2010-11-13 14:26:38', '2010-11-13 14:26:38'),
(374, NULL, NULL, NULL, NULL, 0, 'A', 1, 'CONARPESA CONTINENTAL DE PESCA', '30577856598', NULL, 1, NULL, NULL, 1, '2010-11-12 22:53:38', '2010-11-12 22:53:38'),
(373, NULL, NULL, NULL, NULL, 0, 'A', 1, 'JUAN CARLOS BAITTILLER', '20082661841', NULL, 1, NULL, NULL, 1, '2010-11-11 15:03:01', '2010-11-11 15:03:01'),
(372, NULL, NULL, NULL, NULL, 0, 'A', 1, 'GOBBI NOVAG S A ', '30503270230', NULL, 1, NULL, NULL, 1, '2010-11-11 13:30:29', '2010-11-11 13:30:29'),
(371, NULL, NULL, NULL, NULL, 0, 'A', 1, 'FINCA FLICHMAN S A', '30529496709', NULL, 1, NULL, NULL, 1, '2010-11-10 22:21:32', '2010-11-10 22:21:32'),
(370, NULL, NULL, NULL, NULL, 0, 'A', 1, 'PUBLICIDAD SARMIENTO S R ', '30543217936', NULL, 1, NULL, NULL, 1, '2010-11-10 21:35:06', '2010-11-10 21:35:06'),
(369, NULL, NULL, NULL, NULL, 0, 'A', 1, 'JORGE L CARRANZA S A ', '30638932691', NULL, 1, NULL, NULL, 1, '2010-11-10 20:47:09', '2010-11-10 20:47:09'),
(368, NULL, NULL, NULL, NULL, 0, 'A', 1, 'V R S S R L ', '30708744308', NULL, 1, NULL, NULL, 1, '2010-11-07 23:11:32', '2010-11-07 23:11:32'),
(367, NULL, NULL, NULL, NULL, 0, 'A', 1, 'BASICOS S A ', '30593047578', NULL, 1, NULL, NULL, 1, '2010-11-07 21:47:01', '2010-11-07 21:47:01'),
(366, NULL, NULL, '', '', NULL, '0', 1, 'Sin descuento imprime ticket', '', NULL, 1, '', NULL, 1, '2010-11-06 23:39:40', '2010-11-06 23:39:40'),
(365, NULL, NULL, NULL, NULL, 0, 'A', 1, 'BRUNSTEIN SERGIO', '20045318452', NULL, 1, NULL, NULL, 1, '2010-11-06 23:14:08', '2010-11-06 23:14:08'),
(364, NULL, NULL, NULL, NULL, 0, 'A', 1, 'AGENCIA CORDOBA TURISMO SEM', '33704569349', NULL, 1, NULL, NULL, 1, '2010-11-06 22:42:37', '2010-11-06 22:42:37'),
(363, NULL, NULL, NULL, NULL, 0, 'A', 1, 'MIRAFLORES S R ', '30577350813', NULL, 1, NULL, NULL, 1, '2010-11-04 23:02:37', '2010-11-04 23:02:37'),
(362, NULL, NULL, NULL, NULL, 0, 'A', 1, 'MIRAFLORES  S A', '30577350813', NULL, 1, NULL, NULL, 1, '2010-11-04 23:01:26', '2010-11-04 23:01:26'),
(360, NULL, NULL, NULL, NULL, 0, 'A', 1, 'DIAZ HUGO OMAR', '20133434381', NULL, 1, NULL, NULL, 1, '2010-11-04 22:09:47', '2010-11-04 22:09:47'),
(361, NULL, NULL, NULL, NULL, 0, 'A', 1, 'VALLES ARACELI', '23029362734', NULL, 1, NULL, NULL, 1, '2010-11-04 22:40:02', '2010-11-04 22:40:02'),
(359, NULL, NULL, NULL, NULL, 0, 'A', 1, 'AUTOMOVIL CLUB ARGEN', '30500143297', NULL, 1, NULL, NULL, 1, '2010-11-04 21:51:22', '2010-11-04 21:51:22'),
(358, NULL, NULL, NULL, NULL, 0, 'A', 1, 'TODO RIEGO INSU S R L ', '30708162783', NULL, 1, NULL, NULL, 1, '2010-11-04 14:27:06', '2010-11-04 14:27:06'),
(321, 28, NULL, '', '', NULL, 'A', 1, 'Estancia El Cuero S.R.L.', '30710680864', NULL, 1, 'Av.Libertador 5360 7mo. Piso Cap. Federal', NULL, 1, '2010-09-09 14:19:06', '2010-09-09 14:19:06'),
(357, NULL, NULL, NULL, NULL, 0, 'A', 1, 'A G ENPRENDIMIENTO S R L ', '30710586140', NULL, 1, NULL, NULL, 1, '2010-11-03 13:34:17', '2010-11-03 13:34:17'),
(323, NULL, NULL, '', '', NULL, 'A', 1, 'GNC Gesell S.R.L.', '30708302860', NULL, 1, 'Av Intermedanos 77', NULL, 1, '2010-09-10 21:52:09', '2010-09-10 21:52:09'),
(355, NULL, NULL, NULL, NULL, 0, 'A', 1, 'THAUNS S A', '30709757888', NULL, 1, NULL, NULL, 1, '2010-11-01 21:37:10', '2010-11-01 21:37:10'),
(356, NULL, NULL, NULL, NULL, 0, 'A', 1, 'THAUN S A 30709757888', '30709757888', NULL, 1, NULL, NULL, 1, '2010-11-01 21:40:00', '2010-11-01 21:40:00'),
(354, NULL, NULL, NULL, NULL, 0, 'A', 1, 'SU INMOBILIARIA S R L', '30709928046', NULL, 1, NULL, NULL, 1, '2010-10-31 23:10:37', '2010-10-31 23:10:37'),
(326, NULL, NULL, '', '', NULL, 'A', 1, 'SD Textil Group S.A.', '30710509049', NULL, 1, '', NULL, 1, '2010-09-11 14:11:25', '2010-09-11 14:11:25'),
(352, NULL, NULL, NULL, NULL, 0, 'A', 1, 'GRACIANO', '30629829802', NULL, 1, NULL, NULL, 1, '2010-10-30 14:04:10', '2010-10-30 14:04:10'),
(350, NULL, NULL, NULL, NULL, 0, 'A', 1, 'LA MALDITA', '30710361831', NULL, 1, NULL, NULL, 1, '2010-10-27 23:27:31', '2010-10-27 23:27:31'),
(351, NULL, NULL, NULL, NULL, 0, 'A', 1, 'Vazquez y covini Sacifi', '33538454279', NULL, 1, NULL, NULL, 1, '2010-10-29 23:34:20', '2010-10-29 23:34:20'),
(349, NULL, NULL, NULL, NULL, 0, 'A', 1, 'BASICOS', '30593047578', NULL, 1, NULL, NULL, 1, '2010-10-24 14:24:49', '2010-10-24 14:24:49'),
(348, NULL, NULL, NULL, NULL, 0, 'A', 1, 'TIPOITI SATIC', '30502671126', NULL, 1, NULL, NULL, 1, '2010-10-24 13:32:56', '2010-10-24 13:32:56'),
(346, NULL, NULL, '', '', 10, '0', 1, 'SAN FELIPE', '', NULL, 1, '', NULL, 1, '2010-10-23 23:31:27', '2010-10-23 23:31:27'),
(347, NULL, NULL, NULL, NULL, 0, 'A', 1, 'garcia sergio daniel', '20232459477', NULL, 1, NULL, NULL, 1, '2010-10-24 00:24:10', '2010-10-24 00:24:10'),
(345, NULL, NULL, NULL, NULL, 0, 'A', 1, 'ELCA SEGURIDAD ELECTRONICA SRL', '30684087432', NULL, 1, NULL, NULL, 1, '2010-10-23 22:09:16', '2010-10-23 22:09:16'),
(334, 28, NULL, '', '', NULL, 'A', 1, 'Polimex Argentina S.A.', '30641816066', NULL, 1, '', NULL, 1, '2010-09-15 14:18:05', '2010-09-15 14:18:05'),
(344, NULL, NULL, NULL, NULL, 0, 'A', 1, 'gol maria serena', '27228487290', NULL, 1, NULL, NULL, 1, '2010-10-23 20:50:25', '2010-10-23 20:50:25'),
(342, NULL, NULL, NULL, NULL, 0, 'A', 1, 'RENATO LUCANTO', '20137411904', NULL, 1, NULL, NULL, 1, '2010-10-23 13:46:45', '2010-10-23 13:46:45'),
(343, NULL, NULL, '', '', NULL, '0', 0, 'Sin Descuento y Sin imprimir Ticket', '', NULL, 1, '', NULL, 1, '2010-10-23 16:22:56', '2010-10-23 16:22:56'),
(341, NULL, NULL, '', '', 1, '0', 1, 'Descuento 15%', '', NULL, 1, '', NULL, 1, '2010-10-23 12:23:41', '2010-10-23 12:23:41'),
(338, NULL, NULL, NULL, NULL, 0, 'A', 1, 'paxapoga', '30707370897', NULL, 1, NULL, NULL, 1, '2010-09-20 18:49:48', '2010-09-20 18:49:48'),
(339, NULL, NULL, NULL, NULL, 0, 'A', 1, 'mourgues correa lorena salome', '27249465327', NULL, 1, NULL, NULL, 1, '2010-10-11 14:16:41', '2010-10-11 14:16:41'),
(340, NULL, NULL, NULL, NULL, 0, 'A', 1, 'R. MARCHESE', '30552483924', NULL, 1, NULL, NULL, 1, '2010-10-23 11:52:57', '2010-10-23 11:52:57'),
(409, NULL, NULL, NULL, NULL, 0, 'A', 1, 'AVEDIK S A ', '30710668945', NULL, 1, NULL, NULL, 1, '2010-11-22 15:20:39', '2010-11-22 15:20:39'),
(411, NULL, NULL, NULL, NULL, 0, 'A', 1, 'CHULIVERT HERNAN', '20119864802', NULL, 1, NULL, NULL, 1, '2010-11-25 20:51:23', '2010-11-25 20:51:23'),
(412, NULL, NULL, NULL, NULL, 0, 'A', 1, 'FUNDACION CIENTIFICA DEL SUR', '30642511439', NULL, 1, NULL, NULL, 1, '2010-11-25 22:08:16', '2010-11-25 22:08:16'),
(413, NULL, NULL, NULL, NULL, 0, 'A', 1, 'LINCOLN ELECTRIC S A', '33707167519', NULL, 1, NULL, NULL, 1, '2010-11-25 22:13:18', '2010-11-25 22:13:18'),
(414, NULL, NULL, NULL, NULL, 0, 'A', 1, 'CARLOS DARIANO PIEDRAS', '20211556200', NULL, 1, NULL, NULL, 1, '2010-11-25 22:31:35', '2010-11-25 22:31:35'),
(415, NULL, NULL, NULL, NULL, 0, 'A', 1, 'ORTOPEDIA BERNAL S R L ', '30661143610', NULL, 1, NULL, NULL, 1, '2010-11-26 15:12:00', '2010-11-26 15:12:00'),
(416, NULL, NULL, NULL, NULL, 0, 'A', 1, 'LABORATORIOS MICROSULES ARGENTINA S A ', '30519887335', NULL, 1, NULL, NULL, 1, '2010-11-26 15:19:49', '2010-11-26 15:19:49'),
(417, NULL, NULL, NULL, NULL, 0, 'A', 1, 'COTECSUD S A S E ', '30577873654', NULL, 1, NULL, NULL, 1, '2010-11-26 15:33:57', '2010-11-26 15:33:57'),
(418, NULL, NULL, NULL, NULL, 0, 'A', 1, 'ARQUI FUS S R L ', '30708752270', NULL, 1, NULL, NULL, 1, '2010-11-27 00:19:08', '2010-11-27 00:19:08'),
(419, NULL, NULL, NULL, NULL, 0, 'A', 1, 'GANC HUGO OSVAJDO', '', NULL, 1, NULL, NULL, 1, '2010-11-27 15:58:39', '2010-11-27 15:58:39'),
(420, NULL, NULL, NULL, NULL, 0, 'A', 1, 'GANC HUGO OSVALDO', '20101224164', NULL, 1, NULL, NULL, 1, '2010-11-27 16:01:21', '2010-11-27 16:01:21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comandas`
--

CREATE TABLE IF NOT EXISTS `comandas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mesa_id` int(11) NOT NULL,
  `prioridad` tinyint(4) NOT NULL,
  `impresa` timestamp NULL DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `observacion` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `comandas`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comanderas`
--

CREATE TABLE IF NOT EXISTS `comanderas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `path` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  `imprime_ticket` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'me dice si imprime o no tickets factura',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `comanderas`
--

INSERT INTO `comanderas` (`id`, `name`, `description`, `path`, `imprime_ticket`) VALUES
(1, 'comandera', 'Impresora de la Barra', '/tmp/comanderas/barra', 1),
(3, 'cocina', 'Comandera de la Cocina', '/tmp/comanderas/cocina', 0),
(4, 'SinComandera', 'no imprimir', '/tmp/comanderas/sincomandera', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comensales`
--

CREATE TABLE IF NOT EXISTS `comensales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cant_mayores` tinyint(4) NOT NULL,
  `cant_menores` tinyint(4) NOT NULL,
  `cant_bebes` tinyint(4) NOT NULL,
  `mesa_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `comensales`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `descuentos`
--

CREATE TABLE IF NOT EXISTS `descuentos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `description` text COLLATE utf8_spanish_ci,
  `porcentaje` float NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=18 ;

--
-- Volcar la base de datos para la tabla `descuentos`
--

INSERT INTO `descuentos` (`id`, `name`, `description`, `porcentaje`, `created`, `modified`) VALUES
(1, 'Cliente 15%', 'Descuento que se le da a todos los clintes de Paxapoga', 15, '2009-09-09 22:21:12', '2009-11-22 14:02:07'),
(2, 'invitado gerencia', 'Invitaciones de la casa', 100, '2009-09-09 22:22:15', '2009-09-09 22:22:15'),
(16, 'Tarjeta en efectivo', 'Clientes con tarjeta que pagan en efectivo', 25, '2010-09-03 12:04:58', '2010-09-03 12:04:58'),
(10, 'Cliente 20%', '', 20, '2009-12-05 14:44:45', '2009-12-05 14:45:06'),
(9, 'Cliente 10%', '', 10, '2009-11-22 14:01:55', '2009-12-18 22:09:54'),
(8, 'Remito sin descuento', 'imprime un remito pero sin descuento', 0, '2009-11-21 04:17:21', '2009-11-21 04:17:21'),
(13, '50 %', '', 50, '2009-12-27 00:02:17', '2009-12-27 00:02:17'),
(15, 'Tarjeta con tarjeta', 'Clientes con tarjeta que pagan con tarjeta de credito/debito', 20, '2010-07-15 17:38:04', '2010-09-03 12:05:50'),
(17, 'Sin Dto imprime tik', 'sin descuento e imprime ticket', 0, '2010-11-06 23:38:57', '2010-11-06 23:38:57');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_comandas`
--

CREATE TABLE IF NOT EXISTS `detalle_comandas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `producto_id` int(10) unsigned NOT NULL,
  `cant` tinyint(4) NOT NULL,
  `cant_eliminada` tinyint(4) NOT NULL DEFAULT '0',
  `comanda_id` int(11) unsigned NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `es_entrada` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mesa_id_2` (`comanda_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `detalle_comandas`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_sabores`
--

CREATE TABLE IF NOT EXISTS `detalle_sabores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle_comanda_id` int(11) NOT NULL,
  `sabor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `detalle_sabores`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `egresos`
--

CREATE TABLE IF NOT EXISTS `egresos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `tipo_factura_id` int(11) DEFAULT NULL,
  `iva` float(10,2) DEFAULT '0.00',
  `iibb` float(10,2) DEFAULT '0.00',
  `otros` float(10,2) DEFAULT '0.00',
  `total` float(10,2) NOT NULL DEFAULT '0.00',
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `egresos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gastos`
--

CREATE TABLE IF NOT EXISTS `gastos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `importe` float(10,2) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `gastos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `impfiscales`
--

CREATE TABLE IF NOT EXISTS `impfiscales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `path` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `impfiscales`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iva_responsabilidades`
--

CREATE TABLE IF NOT EXISTS `iva_responsabilidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_fiscal` varchar(1) COLLATE utf8_spanish_ci NOT NULL,
  `name` varchar(24) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `iva_responsabilidades`
--

INSERT INTO `iva_responsabilidades` (`id`, `codigo_fiscal`, `name`) VALUES
(1, 'I', 'Resp. Inscripto'),
(2, 'E', 'Exento'),
(3, 'A', 'No Responsable'),
(4, 'C', 'Consumidor Final'),
(5, 'T', 'No Categorizado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mesas`
--

CREATE TABLE IF NOT EXISTS `mesas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `mozo_id` int(10) unsigned NOT NULL,
  `total` float(10,2) DEFAULT '0.00',
  `cliente_id` int(10) unsigned DEFAULT '0',
  `menu` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'es para cuando un cliente quiere imprimir el importe como MENU sin que se vea lo que consumio',
  `cant_comensales` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `time_cerro` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `time_cobro` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `time_cerro` (`time_cerro`,`time_cobro`),
  KEY `mozo_id` (`mozo_id`),
  KEY `numero` (`numero`),
  KEY `time_cobro` (`time_cobro`),
  KEY `created` (`time_cerro`,`mozo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `mesas`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mozos`
--

CREATE TABLE IF NOT EXISTS `mozos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `numero` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `numero` (`numero`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `mozos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE IF NOT EXISTS `pagos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mesa_id` int(10) unsigned NOT NULL,
  `tipo_de_pago_id` int(10) unsigned NOT NULL,
  `valor` float NOT NULL COMMENT 'por ahora este campo vale cuando el tipo de pago es mixto, entonces se pone la cantidad de efectivo que pagó. Para poder hacer el arqueo.',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `pagos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `abrev` varchar(28) COLLATE utf8_spanish_ci NOT NULL,
  `description` text COLLATE utf8_spanish_ci NOT NULL,
  `categoria_id` int(10) unsigned NOT NULL,
  `precio` float(10,2) NOT NULL,
  `comandera_id` int(11) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `deleted_date` timestamp NULL DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `productos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `queries`
--

CREATE TABLE IF NOT EXISTS `queries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(78) COLLATE utf8_spanish_ci NOT NULL,
  `description` text COLLATE utf8_spanish_ci,
  `query` text COLLATE utf8_spanish_ci NOT NULL,
  `categoria` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  `ver_online` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=21 ;

--
-- Volcar la base de datos para la tabla `queries`
--

INSERT INTO `queries` (`id`, `name`, `description`, `query`, `categoria`, `ver_online`, `created`, `modified`) VALUES
(5, 'HistoricoDeVentas', 'Listado histórico de ventas mostrando la fecha, el total y la cantidad de mesas hechas.', 'SELECT count(*) as "cant. mesas", sum(m.cant_comensales) as "cubiertos" ,sum(m.total) as "total", sum(m.total)/sum(m.cant_comensales) as "promedio x cubierto",DATE_FORMAT(m.created,''%d/%m/%Y - %a %M'') as "fecha" FROM (\r\n	SELECT id,numero,mozo_id,total, cant_comensales, cliente_id,menu, ADDDATE(m.created,-1) as created, modified, time_cerro, time_cobro from mesas m\r\n	where\r\n	HOUR(m.created) BETWEEN 0 AND 8\r\nUNION\r\n	select id,numero,mozo_id,total, cant_comensales, cliente_id,menu, created, modified, time_cerro, time_cobro from mesas m\r\n	where\r\n	HOUR(m.created) BETWEEN 9 AND 24) as m\r\nGROUP BY YEAR(m.created), MONTH(m.created), DAY(m.created)\r\norder by m.created DESC', 'ventas totales', 1, '2009-11-18 23:41:01', '2010-08-23 19:50:52'),
(6, 'CantidadesVendidasDeProductos', 'Listado de todos los productos con la cantidad de veces que fue vendida', '(\r\nselect p.name as producto, c.name as categoria, p.precio as precio,\r\n(sum(d.cant-d.cant_eliminada)) as "cantidad"\r\nfrom productos p\r\nleft join categorias c on p.categoria_id = c.id\r\nleft join detalle_comandas d on (d.producto_id = p.id)\r\n  group by d.producto_id, p.name, c.name\r\norder by c.id, p.id\r\n)\r\nunion all\r\n(\r\nselect p.name as producto, c.name as categoria, p.precio as precio,\r\n0 as "cantidad"\r\nfrom productos p\r\nleft join categorias c on p.categoria_id = c.id\r\nwhere\r\np.id not in (\r\n  select d.producto_id\r\n  from detalle_comandas d\r\n  group by  d.producto_id\r\n)\r\n)\r\norder by cantidad DESC, categoria, producto', 'ranking', 1, '2009-11-18 23:51:31', '2010-11-20 13:30:32'),
(7, 'ComidasQueNoSeVendieronNunca', 'Listado de comidas que nunca fueron pedidas (al menos vÃ­a el sistema Ã©ste)', 'select p.name as producto, c.name as categoria, p.precio as precio  from productos p\r\nleft join categorias c on p.categoria_id = c.id\r\nwhere \r\np.id not in (select d.producto_id from detalle_comandas d group by d.producto_id)\r\n', 'ranking', 1, '2009-11-18 23:56:09', '2009-11-18 23:57:49'),
(11, 'TotalVentasConTipoPago', 'el historico de ventas, pero esta vez muestra el tipo de pago indicando efectivo y con que tarjeta.', 'SELECT DATE_FORMAT(m.created,''%d/%m/%Y '') as "fecha", count(*) as "cant. mesas", sum(m.total) as "total", t.name  FROM (\r\n	SELECT id,numero,mozo_id,total, cliente_id,menu, ADDDATE(m.created,-1) as created, modified, time_cerro, time_cobro from mesas m\r\n	where\r\n	HOUR(m.created) BETWEEN 0 AND 6\r\nUNION\r\n	select id,numero,mozo_id,total, cliente_id,menu, created, modified, time_cerro, time_cobro from mesas m\r\n	where\r\n	HOUR(m.created) BETWEEN 10 AND 24) as m\r\nleft join mozos z on (z.id = m.mozo_id)\r\nleft join pagos p on (p.mesa_id = m.id)\r\nleft join tipo_de_pagos t on (p.tipo_de_pago_id = t.id)\r\nGROUP BY YEAR(m.created), MONTH(m.created), DAY(m.created), t.id, t.name\r\norder by m.created DESC, t.name ASC\r\n', 'ventas totales', 1, '2009-12-08 01:33:46', '2010-02-14 03:11:54'),
(10, 'historicoVentaXmozo', 'es el historicp de ventas de lops mozos. Aparece por fecha, desde el 5 de diciembre del 2009 indicando cantidad de mesas hechas y el total', 'SELECT \r\n  DATE_FORMAT(m.created,''%d/%m/%Y '') as "fecha", \r\n  count(*) as "cant. mesas",\r\n  z.numero as "N° Mozo", \r\n  sum(m.total) as "total"\r\n \r\nFROM (\r\n	SELECT id,numero,mozo_id,total, cliente_id,menu, ADDDATE(m.created,-1) as created, modified, time_cerro, time_cobro from mesas m\r\n	where\r\n	HOUR(m.created) BETWEEN 0 AND 6\r\nUNION\r\n	select id,numero,mozo_id,total, cliente_id,menu, created, modified, time_cerro, time_cobro from mesas m\r\n	where\r\n	HOUR(m.created) BETWEEN 10 AND 24) as m\r\nleft join mozos z ON (z.id = m.mozo_id)\r\nGROUP BY YEAR(m.created), MONTH(m.created), DAY(m.created), z.id, z.numero\r\norder by YEAR(m.created) DESC, MONTH(m.created) DESC, DAY(m.created) DESC, sum(m.total) DESC', 'ventas totales', 1, '2009-12-07 14:20:54', '2010-11-28 12:08:16'),
(12, 'ProductosQueVendioMozo', 'muestra un listado de productos de mas de $60 que cada mozo vendio.', 'select p.name, p.precio, m.numero as mozo, count(*) as cantidad from productos p\r\n\r\nleft join detalle_comandas dc on (dc.producto_id = p.id)\r\n\r\nleft join comandas c on (c.id = dc.comanda_id)\r\n\r\nleft join mesas ms on (ms.id = c.mesa_id)\r\n\r\nleft join mozos m on (m.id = ms.mozo_id)\r\n\r\nwhere p.precio > 59\r\n\r\ngroup by p.id, m.id ORDER BY `p`.`precio`  DESC', '', 1, '2010-01-13 15:50:55', '2010-01-13 15:53:15'),
(13, 'MesasDetalleUltimos15Dias', 'Listado de mesas con su detalle. Dice el monto total, el mozo, el tipo de factura y el descuento.\r\nSolo muestra informacion de los ultimos 15 dias.', 'select m.total as "Total", m.numero as "Numero Mesa", z.numero as "Numero Mozo", d.porcentaje as "Descuento", c.tipofactura as "Tipo Factura", c.imprime_ticket  as "Imprime Ticket SI/NO", c.nombre  as "Cliente Nombre", \r\nc.nrodocumento as clienteCuit, m.created abrio, m.time_cobro cerro, tdp.name tipopago\r\nfrom mesas m\r\nleft join mozos z on (z.id = m.mozo_id)\r\nleft join clientes c on (c.id = m.cliente_id)\r\nleft join descuentos d on (d.id = c.descuento_id)\r\nleft join pagos p on (p.mesa_id = m.id)\r\nleft join tipo_de_pagos tdp on (tdp.id = p.tipo_de_pago_id)\r\nwhere\r\nm.created > DATE_ADD(CURDATE(), INTERVAL -15 DAY)\r\norder by m.created DESC\r\n', 'mesas', 1, '2010-02-01 16:33:20', '2010-03-27 17:32:44'),
(14, 'MensualXMozo', 'Total de ventas Mensual de todos los mozos que trabajaron en paxapoga', 'SELECT YEAR(m.created) as anio ,MONTH(m.created) as mes, u.nombre as nombre, u.apellido as apellido, z.numero as numero, sum(m.total) total, count(m.total)  cant_mesas, avg(m.total) promedio_consumo_por_mesa, sum(m.cant_comensales) as cubiertos, avg(m.cant_comensales) promedio_por_cubierto\r\nfrom mozos z\r\nleft join users u on (z.user_id = u.id)\r\nleft join mesas m on (m.mozo_id = z.id)\r\ngroup by YEAR(m.created) ,MONTH(m.created), u.nombre, u.apellido, z.numero\r\norder by YEAR(m.created) DESC ,MONTH(m.created) DESC, z.numero ASC', 'mozos', 1, '2010-03-23 11:38:39', '2010-04-08 23:17:42'),
(15, 'MejoresMesas', 'Cuales fueron las mejores mesas. La mesa que en promedio mas plata dio? Cual es la mejor plaza?? Aqui esta la respuesta', 'SELECT m.numero mesa, sum(m.total) total, count(m.total) cantidad, avg(m.total) promedio FROM mesas m\r\ngroup by m.numero ORDER BY `total` DESC', 'mesas', 1, '2010-03-23 11:40:09', '2010-03-23 11:40:09'),
(16, 'Egresos', 'Listado de egresos', 'select e.created fecha, e.name concepto, e.total total, e.iva iva, e.iibb iibb, e.otros otros, f.name as "tipo factura",u.nombre as "nombre usuario", u.apellido as "apellido usuario"  from egresos e \r\nleft join users u on (u.id = e.user_id)\r\nleft join tipo_facturas f on (f.id = e.tipo_factura_id)\r\norder by e.created DESC', 'Contabilidad', 1, '2010-04-09 00:21:59', '2010-04-09 00:21:59'),
(17, 'VentasMensuales', 'Total de Ventas mensuales', 'select sum(total) as venta, MONTH(created) as mes, YEAR(created) as anio\r\nfrom mesas\r\ngroup by MONTH(created), YEAR(created)\r\norder by anio DESC, mes DESC', 'ventas totales', 1, '2010-04-20 01:16:43', '2010-04-20 01:18:07'),
(18, 'CantidadesVendidasEnUltimoMesDeProductos', 'Cantidad de veces que cada producto se vendio a lo largo de los ultimos 2 meses. Muestra tanto los que se vendieron como los que no.', '(\r\nselect p.name as producto, c.name as categoria, p.precio as precio,\r\n(sum(d.cant-d.cant_eliminada)) as "cantidad"\r\nfrom productos p\r\nleft join categorias c on p.categoria_id = c.id\r\nleft join detalle_comandas d on (d.producto_id = p.id)\r\nwhere \r\n  d.created > DATE_SUB(curdate(), INTERVAL 30 DAY)\r\n  group by d.producto_id, p.name, c.name\r\norder by c.id, p.id\r\n)\r\nunion all\r\n(\r\nselect p.name as producto, c.name as categoria, p.precio as precio,\r\n0 as "cantidad"\r\nfrom productos p\r\nleft join categorias c on p.categoria_id = c.id\r\nwhere\r\np.id not in (\r\n  select d.producto_id\r\n  from detalle_comandas d\r\n  where\r\n  d.created > DATE_SUB(curdate(), INTERVAL 30 DAY)\r\n  group by  d.producto_id\r\n)\r\n)\r\norder by categoria, producto', 'ranking', 1, '2010-08-19 01:41:46', '2010-08-23 19:50:38'),
(19, 'clientesQueVinieron', '', 'SELECT c.nombre as cliente, m.created as fecha, d.name as descuento FROM mesas m\r\nleft join clientes c on (m.cliente_id = c.id)\r\nleft join descuentos d on(d.id = c.descuento_id )\r\nwhere m.cliente_id > 0\r\norder by m.created desc', 'clientes', 1, '2010-09-15 21:54:14', '2010-09-15 21:54:14'),
(20, 'VentasPorTipoFactura', 'Detalle de ventas diarias agrupadas por tipo de factura', 'SELECT \r\n  count(*) as "cant. mesas", \r\n  sum(cant_comensales) as "cubiertos" ,\r\n  sum(total) as "total", \r\n  sum(total)/sum(cant_comensales) as "promedio x cubierto",\r\n  DATE_FORMAT(created,''%d/%m/%Y - %a %M'') as "fecha",\r\n  CASE tipofactura WHEN ''A'' THEN ''A'' WHEN 0 THEN ''R''  ELSE ''B'' END as tipofactura\r\nFROM (\r\n	SELECT m.id,numero,m.mozo_id,m.total, m.cant_comensales, m.cliente_id, m.menu, ADDDATE(m.created,-1) as created, m.modified, m.time_cerro, m.time_cobro , tipofactura\r\n        from mesas m\r\n        left join clientes c on (c.id = m.cliente_id)\r\n	where\r\n	HOUR(m.created) BETWEEN 0 AND 8\r\nUNION\r\n	select m.id,m.numero,m.mozo_id,m.total, m.cant_comensales, m.cliente_id,m.menu, m.created, m.modified, m.time_cerro, m.time_cobro , tipofactura\r\n        from mesas m\r\n        left join clientes c on (c.id = m.cliente_id)\r\n	where\r\n	HOUR(m.created) BETWEEN 9 AND 24) as m  \r\nGROUP BY YEAR(created), MONTH(created), DAY(created), tipofactura\r\norder by m.created DESC', 'ventas totales', 1, '2010-11-28 13:19:07', '2010-11-28 13:19:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `restaurantes`
--

CREATE TABLE IF NOT EXISTS `restaurantes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `restaurantes`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sabores`
--

CREATE TABLE IF NOT EXISTS `sabores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `precio` float NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `deleted_date` timestamp NULL DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `sabores`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_de_pagos`
--

CREATE TABLE IF NOT EXISTS `tipo_de_pagos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(110) COLLATE utf8_spanish_ci NOT NULL,
  `description` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=13 ;

--
-- Volcar la base de datos para la tabla `tipo_de_pagos`
--

INSERT INTO `tipo_de_pagos` (`id`, `name`, `description`) VALUES
(1, 'Efectivo', 'cobro de dinero en efectivo'),
(2, 'Tarjeta', 'Cobro con cualquiera de las tarjetas admitidas'),
(3, 'Mixto', 'Cobro mezclado entre tarjeta y efectivo'),
(4, 'No Paga', ''),
(5, 'Tarjeta Amex', ''),
(6, 'Tarjeta Visa', ''),
(7, 'Tarjeta Master Card', ''),
(8, 'Tarjeta Visa Debito', ''),
(9, 'Tarjeta Maestro', ''),
(10, 'No volvio Cupon', ''),
(11, 'Dudoso', 'pago que no se si pagaron con tarjeta, efectivo, etc...'),
(12, 'Voucher Cine', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_documentos`
--

CREATE TABLE IF NOT EXISTS `tipo_documentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_fiscal` varchar(1) COLLATE utf8_spanish_ci NOT NULL,
  `name` varchar(24) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=9 ;

--
-- Volcar la base de datos para la tabla `tipo_documentos`
--

INSERT INTO `tipo_documentos` (`id`, `codigo_fiscal`, `name`) VALUES
(1, 'C', 'CUIT'),
(2, 'L', 'CUIL'),
(3, '0', 'Libreta de Enrolamiento'),
(4, '1', 'Libreta CÃ­vica'),
(5, '2', 'DNI'),
(6, '3', 'Pasaporte'),
(7, '4', 'CÃ©dula de Identidad'),
(8, '-', 'Sin identificar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_facturas`
--

CREATE TABLE IF NOT EXISTS `tipo_facturas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `tipo_facturas`
--

INSERT INTO `tipo_facturas` (`id`, `name`, `created`, `modified`) VALUES
(1, 'Factura "A"', '2010-03-27 20:04:20', '2010-03-27 20:04:20'),
(2, 'Factura "B"', '2010-03-27 20:04:27', '2010-03-27 20:04:27'),
(3, 'Remito "X"', '2010-03-27 20:04:36', '2010-03-27 20:04:36'),
(4, 'Factura "M"', '2010-03-27 20:04:42', '2010-03-27 20:04:42'),
(5, 'Factura "C"', '2010-03-27 20:04:48', '2010-03-27 20:04:48'),
(6, 'Vale', '2010-03-27 20:04:54', '2010-03-27 20:04:54'),
(7, 'Otros', '2010-03-27 20:05:18', '2010-03-27 20:05:18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `role` varchar(64) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'invitado',
  `nombre` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `apellido` varchar(40) COLLATE utf8_spanish_ci NOT NULL DEFAULT '''''',
  `telefono` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `domicilio` varchar(110) COLLATE utf8_spanish_ci NOT NULL DEFAULT '''''',
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=44 ;

--
-- Volcar la base de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `nombre`, `apellido`, `telefono`, `domicilio`, `created`, `modified`) VALUES
(1, 'alevilar', '705d9beedfb592b66453eea0a7ada57a92930c55', 'superuser', 'Alejandro', 'Vilar', '4585-7291', 'Lus Viale 2420', '2010-04-08 03:05:06', '2010-04-08 03:05:06'),
(43, 'super', '8b0c0fd147a7d628ac0551bb2acf31330c1a776d', 'principiante', 'Super', '', '', '', '2010-11-28 14:39:12', '2010-11-28 14:39:20');
