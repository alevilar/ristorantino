-- phpMyAdmin SQL Dump
-- version 3.1.2deb1ubuntu0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 29, 2009 at 10:18 PM
-- Server version: 5.0.75
-- PHP Version: 5.2.6-3ubuntu4.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ristorantino`
--

-- --------------------------------------------------------

--
-- Table structure for table `categorias`
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned default NULL,
  `lft` int(10) unsigned default NULL,
  `rght` int(10) unsigned default NULL,
  `name` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `parent` (`parent_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `categorias`
--

INSERT INTO `categorias` (`id`, `parent_id`, `lft`, `rght`, `name`, `description`, `created`, `modified`) VALUES
(1, NULL, 1, 36, 'ROOT', '', '2009-07-26 17:14:08', '2009-07-26 17:14:08'),
(2, 1, 2, 15, 'Bebidas', '', '2009-07-26 17:15:59', '2009-07-26 17:15:59'),
(3, 1, 16, 21, 'Platos Frios', '', '2009-07-26 17:16:11', '2009-07-26 17:16:11'),
(4, 2, 3, 4, 'gaseosas', '', '2009-07-26 17:16:34', '2009-07-26 17:16:34'),
(5, 2, 5, 6, 'Vinos', '', '2009-07-26 17:16:45', '2009-07-26 17:16:45'),
(6, 1, 22, 25, 'Postres', '', '2009-08-10 00:04:27', '2009-08-10 00:04:27'),
(7, 1, 26, 35, 'Plato Principal', '', '2009-08-31 01:17:15', '2009-08-31 01:17:15'),
(8, 7, 27, 28, 'Minutas', '', '2009-08-31 01:17:26', '2009-08-31 01:17:26'),
(9, 7, 29, 30, 'Pescados', '', '2009-08-31 01:17:34', '2009-08-31 01:17:34'),
(10, 7, 31, 32, 'Cazuelas', '', '2009-08-31 01:17:44', '2009-08-31 01:17:44'),
(11, 7, 33, 34, 'Parrilla', '', '2009-08-31 01:17:51', '2009-08-31 01:17:51'),
(12, 3, 17, 18, 'Entradas', '', '2009-08-31 01:18:15', '2009-08-31 01:18:15'),
(13, 3, 19, 20, 'Ensaladas', '', '2009-08-31 01:18:23', '2009-08-31 01:18:23'),
(14, 2, 7, 8, 'Champagne', '', '2009-09-24 00:31:56', '2009-09-24 00:31:56'),
(15, 2, 9, 10, 'Tragos', '', '2009-09-24 00:48:30', '2009-09-24 00:48:30'),
(16, 2, 11, 12, 'CafeterÃ­a', '', '2009-09-24 01:08:30', '2009-09-24 01:08:30'),
(17, 2, 13, 14, 'Cerveza', '', '2009-09-24 01:21:23', '2009-09-24 01:21:23'),
(18, 6, 23, 24, 'Helados', '', '2009-09-29 19:40:41', '2009-09-29 19:40:41');

-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user_id` int(10) unsigned NOT NULL,
  `descuento_id` int(10) unsigned default '0',
  `tipofactura` char(1) default NULL,
  `imprime_ticket` tinyint(1) default '1',
  `denominacion` varchar(110) default NULL,
  `cuit` varchar(11) default '',
  `domicilio_fiscal` varchar(110) default NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`id`, `user_id`, `descuento_id`, `tipofactura`, `imprime_ticket`, `denominacion`, `cuit`, `domicilio_fiscal`, `created`, `modified`) VALUES
(3, 2, 1, '0', 1, '', '', '', '2009-09-09 22:28:23', '2009-09-10 00:21:07'),
(9, 8, NULL, 'A', 1, 'Mongocho S.A.', '30444444444', 'Gaonilla 222', '2009-09-10 17:23:42', '2009-09-10 17:23:42'),
(5, 5, NULL, 'A', 1, '''''', '''''', '0', '2009-09-09 23:46:16', '2009-09-09 23:46:16'),
(7, 6, NULL, 'A', 1, '''''', '''''', '0', '2009-09-09 23:51:51', '2009-09-09 23:51:51'),
(8, 7, 1, 'B', 1, '''''', '''''', '0', '2009-09-09 23:52:19', '2009-09-14 20:26:28'),
(10, 9, 1, '0', 0, '', '', '', '2009-09-11 00:20:49', '2009-09-11 00:20:49'),
(11, 0, NULL, 'A', 1, 'Quilmes SA', '30232323232', 'asasas 2', '2009-09-11 00:22:03', '2009-09-11 00:22:03'),
(12, 10, NULL, 'A', 1, 'Quilmes SA', '30232323232', 'asasas 2', '2009-09-11 00:22:10', '2009-09-11 00:22:10'),
(13, 11, NULL, 'A', 1, 'Negro SRL', '32232323232', 'asd asd 23', '2009-09-12 00:06:38', '2009-09-12 00:06:38'),
(14, 0, NULL, 'A', 1, 'PEPE SA', '32323232323', 'sdf ssd33 33', '2009-09-12 04:24:02', '2009-09-12 04:24:02'),
(15, 0, NULL, 'A', 1, 'PEPE SA', '32323232323', 'sdf ssd33 33', '2009-09-12 04:24:25', '2009-09-12 04:24:25'),
(16, 12, NULL, 'A', 1, 'PEPE SA', '32323232323', 'sdf ssd33 33', '2009-09-12 04:24:37', '2009-09-12 04:24:37'),
(17, 13, NULL, 'A', 1, 'latorre FTBA', '56352625362', 'pepepe 454', '2009-09-12 04:25:17', '2009-09-12 04:25:17'),
(18, 14, NULL, 'A', 1, 'newells old boys SRL', '22222222222', 'rosario y cuenca 322', '2009-09-12 04:26:06', '2009-09-12 04:26:06'),
(19, 15, NULL, 'A', 1, 'Sarlanga Villagras ', '42424242442', 'bobobobn oh 23', '2009-09-12 04:26:49', '2009-09-12 04:26:49');

-- --------------------------------------------------------

--
-- Table structure for table `comandas`
--

CREATE TABLE IF NOT EXISTS `comandas` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `prioridad` tinyint(4) NOT NULL,
  `impresa` timestamp NULL default NULL,
  `created` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `comandas`
--

INSERT INTO `comandas` (`id`, `prioridad`, `impresa`, `created`) VALUES
(1, 0, NULL, '2009-09-29 20:33:29'),
(2, 0, NULL, '2009-09-29 20:34:30'),
(3, 0, NULL, '2009-09-29 20:46:41'),
(4, 0, NULL, '2009-09-29 21:21:24'),
(5, 0, NULL, '2009-09-29 21:21:33'),
(6, 0, NULL, '2009-09-29 22:08:11');

-- --------------------------------------------------------

--
-- Table structure for table `comensales`
--

CREATE TABLE IF NOT EXISTS `comensales` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cant_mayores` tinyint(4) NOT NULL,
  `cant_menores` tinyint(4) NOT NULL,
  `cant_bebes` tinyint(4) NOT NULL,
  `mesa_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comensales`
--


-- --------------------------------------------------------

--
-- Table structure for table `descuentos`
--

CREATE TABLE IF NOT EXISTS `descuentos` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `description` text,
  `porcentaje` float NOT NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `descuentos`
--

INSERT INTO `descuentos` (`id`, `name`, `description`, `porcentaje`, `created`, `modified`) VALUES
(1, 'Cliente', 'Descuento que se le da a todos los clintes de Paxapoga', 15, '2009-09-09 22:21:12', '2009-09-09 22:21:12'),
(2, 'invitado gerencia', 'Invitaciones de la casa', 100, '2009-09-09 22:22:15', '2009-09-09 22:22:15'),
(3, 'invitaciones Pxa', 'invitaciones de paxapoga. Por lo general se eberia utilizar para ocaciones de negocios.', 100, '2009-09-09 22:23:08', '2009-09-09 22:23:08');

-- --------------------------------------------------------

--
-- Table structure for table `detalle_comandas`
--

CREATE TABLE IF NOT EXISTS `detalle_comandas` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `producto_id` int(10) unsigned NOT NULL,
  `cant` tinyint(4) NOT NULL,
  `mesa_id` int(10) unsigned NOT NULL,
  `comanda_id` int(11) unsigned NOT NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `mesa_id` (`mesa_id`),
  KEY `mesa_id_2` (`mesa_id`,`comanda_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `detalle_comandas`
--

INSERT INTO `detalle_comandas` (`id`, `producto_id`, `cant`, `mesa_id`, `comanda_id`, `created`, `modified`) VALUES
(1, 66, 1, 53, 1, '2009-09-29 20:33:29', '2009-09-29 20:33:29'),
(2, 67, 1, 53, 2, '2009-09-29 20:34:30', '2009-09-29 20:34:30'),
(3, 67, 1, 53, 2, '2009-09-29 20:34:30', '2009-09-29 20:34:30'),
(4, 66, 1, 53, 3, '2009-09-29 20:46:41', '2009-09-29 20:46:41'),
(5, 1, 2, 53, 3, '2009-09-29 20:46:41', '2009-09-29 20:46:41'),
(6, 66, 1, 54, 4, '2009-09-29 21:21:24', '2009-09-29 21:21:24'),
(7, 66, 1, 54, 5, '2009-09-29 21:21:33', '2009-09-29 21:21:33'),
(8, 1, 1, 49, 6, '2009-09-29 22:08:11', '2009-09-29 22:08:11');

-- --------------------------------------------------------

--
-- Table structure for table `detalle_sabores`
--

CREATE TABLE IF NOT EXISTS `detalle_sabores` (
  `id` int(11) NOT NULL auto_increment,
  `detalle_comanda_id` int(11) NOT NULL,
  `sabor_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `detalle_sabores`
--

INSERT INTO `detalle_sabores` (`id`, `detalle_comanda_id`, `sabor_id`) VALUES
(1, 1, 2),
(2, 1, 3),
(3, 2, 8),
(4, 2, 9),
(5, 2, 6),
(6, 3, 4),
(7, 4, 3),
(8, 4, 3),
(9, 4, 1),
(10, 6, 2),
(11, 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mesas`
--

CREATE TABLE IF NOT EXISTS `mesas` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `numero` int(11) NOT NULL,
  `mozo_id` int(10) unsigned NOT NULL,
  `total` float(10,2) default '0.00',
  `cliente_id` int(10) unsigned default '0',
  `menu` tinyint(4) NOT NULL default '0' COMMENT 'es para cuando un cliente quiere imprimir el importe como MENU sin que se vea lo que consumio',
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  `time_cerro` timestamp NOT NULL default '0000-00-00 00:00:00',
  `time_cobro` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `time_cerro` (`time_cerro`,`time_cobro`),
  KEY `mozo_id` (`mozo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `mesas`
--

INSERT INTO `mesas` (`id`, `numero`, `mozo_id`, `total`, `cliente_id`, `menu`, `created`, `modified`, `time_cerro`, `time_cobro`) VALUES
(1, 1, 3, NULL, 0, 0, '2009-09-09 02:12:48', '2009-09-16 00:14:10', '2009-09-15 16:48:37', '2009-09-16 00:14:10'),
(2, 5, 3, 8.00, NULL, 0, '2009-09-09 02:38:52', '2009-09-15 02:01:27', '2009-09-14 16:45:54', '2009-09-15 02:01:27'),
(4, 56, 3, 99.00, 0, 9, '2009-09-10 18:25:44', '2009-09-13 23:37:53', '2009-09-13 20:44:24', '2009-09-13 23:37:53'),
(5, 3, 3, 0.00, 11, 0, '2009-09-11 00:05:37', '2009-09-13 23:43:13', '2009-09-13 19:46:26', '2009-09-13 23:43:13'),
(6, 33, 3, 67.00, 0, 0, '2009-09-11 19:16:18', '2009-09-14 17:13:33', '2009-09-14 17:12:41', '2009-09-14 17:13:33'),
(7, 31, 1, 6.00, 0, 0, '2009-09-11 22:18:48', '2009-09-13 23:47:30', '2009-09-13 23:47:11', '2009-09-13 23:47:30'),
(8, 2, 8, 0.00, 13, 4, '2009-09-11 23:57:12', '2009-09-12 00:08:58', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 5, 8, 0.00, 0, 0, '2009-09-12 00:08:29', '2009-09-12 00:08:29', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 6, 4, 0.00, 0, 0, '2009-09-12 05:27:34', '2009-09-13 23:43:05', '2009-09-13 19:52:42', '2009-09-13 23:43:05'),
(11, 2, 3, 56.00, 17, 2, '2009-09-13 19:44:03', '2009-09-15 17:10:58', '2009-09-15 16:48:32', '2009-09-15 17:10:58'),
(12, 88, 2, 0.00, 0, 0, '2009-09-13 19:51:50', '2009-09-13 23:39:34', '2009-09-13 19:53:06', '2009-09-13 23:39:34'),
(13, 22, 2, 0.00, 0, 0, '2009-09-13 20:42:27', '2009-09-13 23:42:51', '2009-09-13 20:43:29', '2009-09-13 23:42:51'),
(14, 33, 2, 8.00, 0, 0, '2009-09-13 23:40:35', '2009-09-13 23:41:13', '2009-09-13 23:40:57', '2009-09-13 23:41:13'),
(15, 5, 2, 11.00, 9, 0, '2009-09-13 23:44:41', '2009-09-13 23:46:18', '2009-09-13 23:45:11', '2009-09-13 23:46:18'),
(16, 1, 6, 6.00, 0, 0, '2009-09-13 23:48:28', '2009-09-13 23:49:33', '2009-09-13 23:48:49', '2009-09-13 23:49:33'),
(17, 58, 4, 66.00, 0, 0, '2009-09-13 23:50:37', '2009-09-13 23:52:14', '2009-09-13 23:51:42', '2009-09-13 23:52:14'),
(18, 2, 1, 6.00, 0, 0, '2009-09-14 17:12:59', '2009-09-14 17:13:39', '2009-09-14 17:13:14', '2009-09-14 17:13:39'),
(19, 32, 3, 8.00, 13, 2, '2009-09-14 19:00:49', '2009-09-14 19:06:25', '2009-09-14 19:01:43', '2009-09-14 19:06:25'),
(20, 2, 2, 24.00, 9, 2, '2009-09-15 01:24:45', '2009-09-15 01:59:08', '2009-09-15 01:58:18', '2009-09-15 01:59:08'),
(21, 1, 6, 6.00, 0, 0, '2009-09-15 01:25:31', '2009-09-15 02:05:25', '2009-09-15 02:02:41', '2009-09-15 02:05:25'),
(22, 66, 1, 45.00, 12, 3, '2009-09-15 01:44:41', '2009-09-15 01:46:25', '2009-09-15 01:46:06', '2009-09-15 01:46:25'),
(23, 101, 4, 117.00, 0, 0, '2009-09-15 01:48:31', '2009-09-15 16:46:21', '2009-09-15 16:44:00', '2009-09-15 16:46:21'),
(24, 2, 6, 8.00, 0, 0, '2009-09-15 02:03:52', '2009-09-15 02:08:31', '2009-09-15 02:04:02', '2009-09-15 02:08:31'),
(25, 33, 6, 8.00, 0, 0, '2009-09-15 02:10:21', '2009-09-15 02:12:27', '2009-09-15 02:10:55', '2009-09-15 02:12:27'),
(26, 22, 6, 8.00, 0, 0, '2009-09-15 02:13:57', '2009-09-15 02:15:07', '2009-09-15 02:14:08', '2009-09-15 02:15:07'),
(27, 23, 6, 6.00, 0, 0, '2009-09-15 02:14:27', '2009-09-15 02:16:32', '2009-09-15 02:14:42', '2009-09-15 02:16:32'),
(28, 24, 6, 24.00, 0, 0, '2009-09-15 02:17:13', '2009-09-15 02:18:19', '2009-09-15 02:17:26', '2009-09-15 02:18:19'),
(29, 25, 6, 6.00, 0, 0, '2009-09-15 02:18:42', '2009-09-15 02:19:13', '2009-09-15 02:18:55', '2009-09-15 02:19:13'),
(30, 26, 6, 33.00, 0, 0, '2009-09-15 02:19:58', '2009-09-15 02:20:23', '2009-09-15 02:20:10', '2009-09-15 02:20:23'),
(31, 1, 11, 48.00, 12, 2, '2009-09-15 15:27:57', '2009-09-15 15:32:48', '2009-09-15 15:32:34', '2009-09-15 15:32:48'),
(32, 2, 11, 6.00, 0, 0, '2009-09-15 15:33:07', '2009-09-15 15:33:30', '2009-09-15 15:33:21', '2009-09-15 15:33:30'),
(33, 22, 11, 0.00, 0, 0, '2009-09-15 16:26:35', '2009-09-15 16:26:35', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 33, 11, 0.00, 0, 0, '2009-09-15 16:36:52', '2009-09-15 16:36:52', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 1, 4, 217.00, 8, 0, '2009-09-15 16:40:44', '2009-09-15 16:46:18', '2009-09-15 16:43:27', '2009-09-15 16:46:18'),
(36, 3, 3, 0.00, 0, 0, '2009-09-15 16:48:41', '2009-09-15 16:48:41', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 66, 4, 40.00, 0, 0, '2009-09-15 16:49:58', '2009-09-15 17:11:02', '2009-09-15 16:50:09', '2009-09-15 17:11:02'),
(38, 25, 4, 33.00, 0, 0, '2009-09-15 16:55:27', '2009-09-15 17:11:42', '2009-09-15 17:11:18', '2009-09-15 17:11:42'),
(39, 2, 1, 6.00, 0, 0, '2009-09-16 00:06:59', '2009-09-16 00:08:21', '2009-09-16 00:08:08', '2009-09-16 00:08:21'),
(40, 22, 5, 18.00, 0, 0, '2009-09-16 00:14:56', '2009-09-16 00:15:17', '2009-09-16 00:15:08', '2009-09-16 00:15:17'),
(41, 23, 5, 60.00, 0, 0, '2009-09-16 00:15:30', '2009-09-16 00:15:53', '2009-09-16 00:15:46', '2009-09-16 00:15:53'),
(42, 22, 2, 12.00, 0, 0, '2009-09-16 00:17:15', '2009-09-16 00:45:08', '2009-09-16 00:18:47', '2009-09-16 00:45:08'),
(43, 23, 2, 6.00, 0, 0, '2009-09-16 00:17:30', '2009-09-16 00:43:55', '2009-09-16 00:18:17', '2009-09-16 00:43:55'),
(44, 11, 2, 40.00, 0, 0, '2009-09-16 00:45:28', '2009-09-16 00:46:02', '2009-09-16 00:45:38', '2009-09-16 00:46:02'),
(45, 13, 2, 18.00, 0, 0, '2009-09-16 00:45:43', '2009-09-16 00:46:33', '2009-09-16 00:45:54', '2009-09-16 00:46:33'),
(46, 14, 2, 24.00, 0, 0, '2009-09-16 00:46:12', '2009-09-16 00:47:07', '2009-09-16 00:46:25', '2009-09-16 00:47:07'),
(47, 15, 2, 12.00, 0, 0, '2009-09-16 00:47:18', '2009-09-16 00:47:48', '2009-09-16 00:47:28', '2009-09-16 00:47:48'),
(48, 11, 1, 6.00, 0, 0, '2009-09-16 21:39:59', '2009-09-16 21:40:08', '2009-09-16 21:40:08', '0000-00-00 00:00:00'),
(49, 308, 1, 0.00, 0, 0, '2009-09-17 00:48:07', '2009-09-17 00:48:07', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(50, 32, 3, 0.00, 0, 0, '2009-09-25 01:33:10', '2009-09-25 01:33:10', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(51, 4, 3, 0.00, 0, 0, '2009-09-28 00:43:53', '2009-09-28 00:43:53', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(52, 5, 3, 0.00, 0, 0, '2009-09-28 00:45:56', '2009-09-28 00:45:56', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(53, 2, 2, 0.00, 0, 0, '2009-09-29 19:48:11', '2009-09-29 19:48:11', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(54, 3, 2, 0.00, 0, 0, '2009-09-29 21:21:10', '2009-09-29 21:21:10', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `mozos`
--

CREATE TABLE IF NOT EXISTS `mozos` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user_id` int(10) unsigned NOT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `mozos`
--

INSERT INTO `mozos` (`id`, `user_id`, `numero`) VALUES
(1, 1, 10),
(2, 1, 11),
(3, 1, 1),
(4, 1, 2),
(5, 1, 3),
(6, 1, 4),
(7, 1, 5),
(8, 1, 6),
(9, 1, 7),
(10, 1, 8),
(11, 1, 16);

-- --------------------------------------------------------

--
-- Table structure for table `pagos`
--

CREATE TABLE IF NOT EXISTS `pagos` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `mesa_id` int(10) unsigned NOT NULL,
  `tipo_de_pago_id` int(10) unsigned NOT NULL,
  `valor` float NOT NULL COMMENT 'por ahora este campo vale cuando el tipo de pago es mixto, entonces se pone la cantidad de efectivo que pagó. Para poder hacer el arqueo.',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `pagos`
--

INSERT INTO `pagos` (`id`, `mesa_id`, `tipo_de_pago_id`, `valor`) VALUES
(2, 4, 1, 99),
(3, 12, 1, 0),
(4, 14, 2, 8),
(5, 13, 2, 0),
(6, 10, 1, 0),
(7, 5, 1, 0),
(8, 15, 2, 11),
(9, 7, 1, 6),
(10, 16, 1, 6),
(11, 17, 1, 66),
(12, 17, 1, 66),
(13, 6, 2, 67),
(14, 18, 1, 6),
(15, 19, 2, 8),
(16, 22, 1, 45),
(17, 20, 1, 24),
(18, 20, 1, 24),
(19, 20, 1, 24),
(20, 20, 1, 24),
(21, 20, 1, 24),
(22, 2, 1, 8),
(23, 2, 1, 8),
(24, 2, 1, 8),
(25, 2, 1, 8),
(26, 2, 1, 8),
(27, 21, 1, 6),
(28, 24, 1, 8),
(29, 25, 1, 8),
(30, 26, 1, 8),
(31, 27, 1, 6),
(32, 28, 2, 24),
(33, 29, 2, 6),
(34, 30, 2, 33),
(35, 31, 1, 48),
(36, 32, 1, 6),
(37, 35, 1, 217),
(38, 35, 1, 217),
(39, 23, 2, 117),
(40, 11, 1, 56),
(41, 37, 1, 40),
(42, 38, 1, 33),
(43, 39, 1, 6),
(44, 1, 1, 0),
(45, 40, 2, 18),
(46, 41, 1, 60),
(47, 43, 1, 6),
(48, 42, 1, 12),
(49, 44, 2, 40),
(50, 45, 1, 18),
(51, 46, 2, 24),
(52, 47, 1, 12);

-- --------------------------------------------------------

--
-- Table structure for table `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(30) NOT NULL,
  `abrev` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `categoria_id` int(10) unsigned NOT NULL,
  `precio` float(10,2) NOT NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `productos`
--

INSERT INTO `productos` (`id`, `name`, `abrev`, `description`, `categoria_id`, `precio`, `created`, `modified`) VALUES
(1, 'Pepsi', 'gaseosa', '', 4, 6.00, '2009-07-26 17:17:51', '2009-09-24 00:54:24'),
(2, '7up', 'gaseosa', '', 4, 6.00, '2009-07-26 17:19:11', '2009-09-24 00:18:47'),
(10, 'Baron B', 'Baron B', '', 14, 80.00, '2009-09-24 00:33:13', '2009-09-24 00:33:13'),
(11, 'Chandon Extra Brut', 'Chandon Ext. Brut', '', 14, 65.00, '2009-09-24 00:40:34', '2009-09-24 00:46:18'),
(12, 'Chandon 187', 'Chandon 187', '', 14, 15.00, '2009-09-24 00:41:30', '2009-09-24 00:41:30'),
(13, 'Whisky Chivas', 'W. Chivas', '', 15, 22.00, '2009-09-24 00:51:10', '2009-09-24 00:51:10'),
(14, 'Paso de los Toros', 'gaseosa', '', 4, 6.00, '2009-09-24 00:52:39', '2009-09-24 00:52:39'),
(15, 'Whisky Johny Walker', 'W. Johny Walker', '', 15, 18.00, '2009-09-24 00:52:45', '2009-09-24 00:52:45'),
(16, 'Paso de los Toros Pomelo', 'gaseosa', '', 4, 6.00, '2009-09-24 00:53:38', '2009-09-24 00:53:38'),
(17, 'Fanta', 'gaseosa', '', 4, 6.00, '2009-09-24 00:53:57', '2009-09-24 00:53:57'),
(18, 'Whisky J & B', 'W. J & B', '', 15, 16.00, '2009-09-24 00:54:14', '2009-09-24 00:54:14'),
(19, 'Pepsi Max', 'gaseosa', '', 4, 6.00, '2009-09-24 00:54:16', '2009-09-24 00:54:16'),
(20, 'Agua Mineral', 'gaseosa', '', 4, 6.00, '2009-09-24 00:54:54', '2009-09-24 00:54:54'),
(21, 'Agua Gasificada', 'gaseosa', '', 4, 6.00, '2009-09-24 00:55:17', '2009-09-24 00:55:17'),
(22, 'Jugo de Naranja', 'Jugo Naranja', '', 4, 9.00, '2009-09-24 00:56:01', '2009-09-24 00:56:01'),
(23, 'Jugo LimÃ³n', 'Jugo LimÃ³n', '', 4, 3.00, '2009-09-24 00:56:43', '2009-09-24 00:56:43'),
(24, 'Clericot', 'Clericot', '', 15, 26.00, '2009-09-24 00:59:27', '2009-09-24 00:59:27'),
(25, '1/2 Clericot', '1/2 Clericot', '', 15, 20.00, '2009-09-24 01:00:17', '2009-09-24 01:00:17'),
(26, 'Sidra', 'Sidra', '', 15, 15.00, '2009-09-24 01:01:25', '2009-09-24 01:01:25'),
(27, 'Americano Gancia', 'Americano Gancia', '', 15, 9.00, '2009-09-24 01:02:18', '2009-09-24 01:02:18'),
(28, 'CoÃ±ac Reserva San Juan', 'CoÃ±ac Res. San Juan', '', 15, 9.00, '2009-09-24 01:04:20', '2009-09-24 01:04:20'),
(29, 'Fernet', 'Fernet', '', 15, 8.00, '2009-09-24 01:05:21', '2009-09-24 01:05:21'),
(30, 'Jerez EspaÃ±ol', 'Jerez EspaÃ±ol', '', 15, 6.00, '2009-09-24 01:06:41', '2009-09-24 01:06:41'),
(31, 'TÃ­a MarÃ­a', 'TÃ­a MarÃ­a', '', 15, 6.00, '2009-09-24 01:07:21', '2009-09-24 01:07:21'),
(32, 'CafÃ©', 'CafÃ©', '', 16, 6.00, '2009-09-24 01:12:29', '2009-09-24 01:12:29'),
(33, 'CafÃ© cortado', 'CafÃ© cortado', '', 16, 6.00, '2009-09-24 01:13:19', '2009-09-24 01:13:19'),
(34, 'CafÃ© con crema', 'CafÃ© c/crema', '', 16, 6.00, '2009-09-24 01:14:29', '2009-09-24 01:14:29'),
(35, 'LÃ¡grima', 'LÃ¡grima', '', 16, 6.00, '2009-09-24 01:15:20', '2009-09-24 01:15:20'),
(36, 'CafÃ© doble', 'CafÃ© doble', '', 16, 8.00, '2009-09-24 01:16:18', '2009-09-24 01:16:18'),
(37, 'TÃ©', 'TÃ©', '', 16, 6.00, '2009-09-24 01:17:27', '2009-09-24 01:17:27'),
(38, 'TÃ© Boldo', 'TÃ© Boldo', '', 16, 6.00, '2009-09-24 01:18:15', '2009-09-24 01:18:15'),
(39, 'TÃ© Manzanilla', 'TÃ© Manzanilla', '', 16, 6.00, '2009-09-24 01:19:24', '2009-09-24 01:19:24'),
(40, 'TÃ© - varios', 'TÃ© - varios', '', 16, 6.00, '2009-09-24 01:20:26', '2009-09-24 01:20:26'),
(41, 'Quilmes', 'Quilmes', '', 17, 11.00, '2009-09-24 01:22:14', '2009-09-24 01:22:14'),
(42, 'Quilmes Cristal 1/3', 'Quilmes Cristal 1/3', '', 17, 7.00, '2009-09-24 01:23:07', '2009-09-24 01:23:07'),
(43, 'Quilmes Bock o Stout 1/3', 'Q. Bock o Stout 1/3', '', 17, 8.00, '2009-09-24 01:24:44', '2009-09-24 01:24:44'),
(44, 'Stella Artois 1/3', 'Stella Artois 1/3', '', 17, 10.00, '2009-09-24 01:25:29', '2009-09-24 01:25:29'),
(45, 'MelÃ³n con jamÃ³n crudo', 'MelÃ³n c/jamÃ³n crud', '', 12, 19.00, '2009-09-24 01:51:36', '2009-09-24 01:51:36'),
(46, 'MelÃ³n con jamÃ³n cocido', 'MelÃ³n c/jamÃ³n coci', '', 12, 16.00, '2009-09-24 01:52:37', '2009-09-24 01:52:37'),
(47, 'JamÃ³n crudo c/ensalada rusa', 'JamÃ³n crudo c/rusa', '', 12, 19.00, '2009-09-24 01:53:56', '2009-09-24 01:59:25'),
(48, 'JamÃ³n cocido c/ensalada rusa', 'JamÃ³n cocido c/rusa', '', 12, 16.00, '2009-09-24 01:55:23', '2009-09-24 01:58:48'),
(49, 'JamÃ³n crudo con anana', 'JamÃ³n crudo c/anana', '', 12, 19.00, '2009-09-24 01:56:53', '2009-09-24 01:58:10'),
(50, 'JamÃ³n cocido con ananÃ¡', 'JamÃ³n cocido c/anan', '', 12, 16.00, '2009-09-24 01:57:44', '2009-09-24 01:57:44'),
(51, 'Fiambre surtido', 'Fiambre surtido', '', 12, 19.00, '2009-09-24 02:00:11', '2009-09-24 02:00:11'),
(52, 'Tabla quesos (2 pers.)', 'Tabla quesos (2 p)', '', 12, 19.00, '2009-09-24 02:01:49', '2009-09-24 02:01:49'),
(53, 'Vithel Thone', 'Vithel Thone', '', 12, 16.00, '2009-09-24 02:02:44', '2009-09-24 02:02:44'),
(54, 'Palmitos c/salsa golf', 'Palmitos c/s. golf', '', 12, 16.00, '2009-09-24 02:03:47', '2009-09-24 02:03:47'),
(55, 'Mayonesa de ave', 'Mayonesa de ave', '', 12, 15.00, '2009-09-24 02:04:24', '2009-09-24 02:04:24'),
(56, 'Mayonesa de atÃºn', 'Mayonesa de atÃºn', '', 12, 17.00, '2009-09-24 02:05:03', '2009-09-24 02:05:03'),
(57, 'SalpicÃ³n americano', 'SalpicÃ³n americano', '', 12, 17.00, '2009-09-24 02:05:40', '2009-09-24 02:05:40'),
(58, 'Copa de camarones', 'Copa de camarones', '', 12, 28.00, '2009-09-24 02:06:18', '2009-09-24 02:06:18'),
(59, 'Matambre casero c/ens. rusa', 'Matambre c/ens. rusa', '', 12, 17.00, '2009-09-24 02:07:37', '2009-09-24 02:07:37'),
(60, 'AtÃºn con cebolla', 'AtÃºn con cebolla', '', 12, 17.00, '2009-09-24 02:08:30', '2009-09-24 02:08:30'),
(61, 'Sardinas con cebolla', 'Sardinas con cebolla', '', 12, 18.00, '2009-09-24 02:09:10', '2009-09-24 02:09:10'),
(62, 'Lengua a la vinagreta', 'Lengua vinagreta', '', 12, 15.00, '2009-09-24 02:09:54', '2009-09-24 02:09:54'),
(63, 'Berenjenas en escabeche', 'Berenjenas escabeche', '', 12, 13.00, '2009-09-24 02:10:55', '2009-09-24 02:10:55'),
(64, 'Berenjenas napolitana', 'Berenjenas napol.', '', 12, 17.00, '2009-09-24 02:11:43', '2009-09-24 02:11:43'),
(65, 'Milanesas a la mozzarella', 'Milanesas mozzarella', '', 12, 15.00, '2009-09-24 02:12:55', '2009-09-24 02:12:55'),
(66, 'Ensalada Mixta', 'Mixta', '', 13, 9.00, '2009-09-28 16:35:02', '2009-09-28 16:35:02'),
(67, 'Copa Helada', 'Copa Helada', '', 18, 8.00, '2009-09-29 19:47:51', '2009-09-29 19:47:51');

-- --------------------------------------------------------

--
-- Table structure for table `restaurantes`
--

CREATE TABLE IF NOT EXISTS `restaurantes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `restaurantes`
--


-- --------------------------------------------------------

--
-- Table structure for table `sabores`
--

CREATE TABLE IF NOT EXISTS `sabores` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(64) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `sabores`
--

INSERT INTO `sabores` (`id`, `name`, `categoria_id`, `created`, `modified`) VALUES
(1, 'Zanahoria', 13, '2009-09-28 16:19:10', '2009-09-28 16:19:10'),
(2, 'Lechuga', 13, '2009-09-28 16:19:19', '2009-09-28 16:19:19'),
(3, 'Tomate', 13, '2009-09-28 16:19:33', '2009-09-28 16:19:33'),
(4, 'Chocolate', 18, '2009-09-29 19:41:09', '2009-09-29 19:41:09'),
(5, 'Crema', 18, '2009-09-29 19:41:19', '2009-09-29 19:41:19'),
(6, 'Vainilla', 18, '2009-09-29 19:41:29', '2009-09-29 19:41:29'),
(7, 'Frutilla', 18, '2009-09-29 19:41:41', '2009-09-29 19:41:41'),
(8, 'Dulce de Leche', 18, '2009-09-29 19:41:53', '2009-09-29 19:41:53'),
(9, 'LimÃ³n', 18, '2009-09-29 19:42:08', '2009-09-29 19:42:08');

-- --------------------------------------------------------

--
-- Table structure for table `tipo_de_pagos`
--

CREATE TABLE IF NOT EXISTS `tipo_de_pagos` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(110) NOT NULL,
  `description` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tipo_de_pagos`
--

INSERT INTO `tipo_de_pagos` (`id`, `name`, `description`) VALUES
(1, 'Efectivo', 'cobro de dinero en efectivo'),
(2, 'Tarjeta', 'Cobro con cualquiera de las tarjetas admitidas'),
(3, 'Mixto', 'Cobro mezclado entre tarjeta y efectivo');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(64) NOT NULL default 'invitado',
  `nombre` varchar(40) NOT NULL,
  `apellido` varchar(40) NOT NULL,
  `telefono` varchar(20) default NULL,
  `domicilio` varchar(110) NOT NULL default '''''',
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `nombre`, `apellido`, `telefono`, `domicilio`, `created`, `modified`) VALUES
(1, 'alevilar', '8fb60eac807682911c163fe06a82988360a6c941', 'guest', 'alejandro', 'vilar', '45857291', '''''', NULL, NULL),
(2, 'pepe', 'a3c93d44750c431d5a0e48a17a6706a1cb2b7d0c', 'cliente', 'pepe ruiz', 'ramirez', '456456654', '''''', NULL, '2009-09-10 00:21:07'),
(4, 'manolo', '8c18f5466c2eafeb6630f4b1c9f9b45e7e53bce6', 'cliente', 'Manu manolo', 'Gomez', '', '''''', NULL, NULL),
(5, 'manolo2', '683e1f05e0982b2e4601a370349bb219d094b5be', 'cliente', 'Manu manolo', 'Gomez', '', '''''', NULL, NULL),
(6, 'maradona', '27515c964782e7985a6570913744a76c99a9cc21', 'cliente', 'Diego Armando', 'maradona', '', '''''', NULL, NULL),
(7, 'coppola', '2b6cb9fe7da448785c7d9a4aca9099f2955a923b', 'cliente', 'Guillote', 'Coppola', '', '''''', NULL, '2009-09-14 20:26:28'),
(8, 'mongocho', '58f9e11265b7904a8777a2acfdae7489a2422bd9', 'cliente', 'mongo', 'mongocho', '', '''''', '2009-09-10 17:23:42', '2009-09-10 17:23:42'),
(9, 'julia', '261f76decd6652b6161997bc61a90e8ad1c340bb', 'cliente', 'julia', 'nigro', '45014478', '''''', '2009-09-11 00:20:49', '2009-09-11 00:20:49'),
(10, 'quilmes', 'd0f071d9f0bdfcc3bcadaf413227b8c65cf530e5', 'cliente', 'quilmes', 'lala', '', '''''', '2009-09-11 00:22:10', '2009-09-11 00:22:10'),
(11, 'negro', '4a637987924490ff9531b7e43a5a23df98746b3d', 'cliente', 'Matias', 'Araneda', '', '''''', '2009-09-12 00:06:38', '2009-09-12 00:06:38'),
(12, 'batistita', '0e7a821acfd6f8a0df532de902e8edf3acc5b7b8', 'cliente', 'batistita', 'batisnada', '', '''''', '2009-09-12 04:24:37', '2009-09-12 04:24:37'),
(13, 'latorre', '90e620fd2f197d210999aaa3be1ae3e3bf85927f', 'cliente', 'Diego', 'Latorre', '', '''''', '2009-09-12 04:25:17', '2009-09-12 04:25:17'),
(14, 'schiavi', 'dba712373b4b33477a9cd05c8cb02f60deacf58a', 'cliente', 'rolando', 'schiavi', '232323232', '''''', '2009-09-12 04:26:06', '2009-09-12 04:26:06'),
(15, 'villagra', '7d04a92499007f40931c853740784a31c0d37000', 'cliente', 'carliÃ±os', 'villagra', '', '''''', '2009-09-12 04:26:49', '2009-09-12 04:26:49'),
(16, 'alejandro', '8fb60eac807682911c163fe06a82988360a6c941', 'gerente', 'Alejandro', 'Vilar', '', '''''', '2009-09-14 19:02:32', '2009-09-14 19:02:32');
