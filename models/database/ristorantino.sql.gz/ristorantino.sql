-- phpMyAdmin SQL Dump
-- version 3.1.2deb1ubuntu0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 10, 2009 at 12:22 AM
-- Server version: 5.0.75
-- PHP Version: 5.2.6-3ubuntu4.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ristorantino`
--

-- --------------------------------------------------------

--
-- Table structure for table `categorias`
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned default NULL,
  `lft` int(10) unsigned default NULL,
  `rght` int(10) unsigned default NULL,
  `name` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `parent` (`parent_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `categorias`
--

INSERT INTO `categorias` (`id`, `parent_id`, `lft`, `rght`, `name`, `description`, `created`, `modified`) VALUES
(1, NULL, 1, 26, 'ROOT', '', '2009-07-26 17:14:08', '2009-07-26 17:14:08'),
(2, 1, 2, 7, 'Bebidas', '', '2009-07-26 17:15:59', '2009-07-26 17:15:59'),
(3, 1, 8, 13, 'Platos Frios', '', '2009-07-26 17:16:11', '2009-07-26 17:16:11'),
(4, 2, 3, 4, 'gaseosas', '', '2009-07-26 17:16:34', '2009-07-26 17:16:34'),
(5, 2, 5, 6, 'Vinos', '', '2009-07-26 17:16:45', '2009-07-26 17:16:45'),
(6, 1, 14, 15, 'Postres', '', '2009-08-10 00:04:27', '2009-08-10 00:04:27'),
(7, 1, 16, 25, 'Plato Principal', '', '2009-08-31 01:17:15', '2009-08-31 01:17:15'),
(8, 7, 17, 18, 'Minutas', '', '2009-08-31 01:17:26', '2009-08-31 01:17:26'),
(9, 7, 19, 20, 'Pescados', '', '2009-08-31 01:17:34', '2009-08-31 01:17:34'),
(10, 7, 21, 22, 'Cazuelas', '', '2009-08-31 01:17:44', '2009-08-31 01:17:44'),
(11, 7, 23, 24, 'Parrilla', '', '2009-08-31 01:17:51', '2009-08-31 01:17:51'),
(12, 3, 9, 10, 'Entradas', '', '2009-08-31 01:18:15', '2009-08-31 01:18:15'),
(13, 3, 11, 12, 'Ensaladas', '', '2009-08-31 01:18:23', '2009-08-31 01:18:23');

-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user_id` int(10) unsigned NOT NULL,
  `descuento_id` int(10) unsigned default '0',
  `tipofactura` char(1) default NULL,
  `imprime_ticket` tinyint(1) default '1',
  `denominacion` varchar(110) default NULL,
  `cuit` varchar(11) default '',
  `domicilio_fiscal` varchar(110) default NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`id`, `user_id`, `descuento_id`, `tipofactura`, `imprime_ticket`, `denominacion`, `cuit`, `domicilio_fiscal`, `created`, `modified`) VALUES
(3, 2, 1, '0', 1, '', '', '', '2009-09-09 22:28:23', '2009-09-10 00:21:07'),
(4, 0, NULL, 'A', 1, '''''', '''''', '0', '2009-09-09 23:46:03', '2009-09-09 23:46:03'),
(5, 5, NULL, 'A', 1, '''''', '''''', '0', '2009-09-09 23:46:16', '2009-09-09 23:46:16'),
(7, 6, NULL, 'A', 1, '''''', '''''', '0', '2009-09-09 23:51:51', '2009-09-09 23:51:51'),
(8, 7, 1, 'N', 0, '''''', '''''', '0', '2009-09-09 23:52:19', '2009-09-09 23:52:19');

-- --------------------------------------------------------

--
-- Table structure for table `comandas`
--

CREATE TABLE IF NOT EXISTS `comandas` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `prioridad` tinyint(4) NOT NULL,
  `impresa` timestamp NULL default NULL,
  `created` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `comandas`
--

INSERT INTO `comandas` (`id`, `prioridad`, `impresa`, `created`) VALUES
(1, 1, NULL, '2009-09-09 02:13:08'),
(2, 1, NULL, '2009-09-09 02:13:29'),
(3, 1, NULL, '2009-09-09 17:22:03');

-- --------------------------------------------------------

--
-- Table structure for table `comensales`
--

CREATE TABLE IF NOT EXISTS `comensales` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cant_mayores` tinyint(4) NOT NULL,
  `cant_menores` tinyint(4) NOT NULL,
  `cant_bebes` tinyint(4) NOT NULL,
  `mesa_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comensales`
--


-- --------------------------------------------------------

--
-- Table structure for table `descuentos`
--

CREATE TABLE IF NOT EXISTS `descuentos` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `description` text,
  `porcentaje` float NOT NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `descuentos`
--

INSERT INTO `descuentos` (`id`, `name`, `description`, `porcentaje`, `created`, `modified`) VALUES
(1, 'Cliente', 'Descuento que se le da a todos los clintes de Paxapoga', 15, '2009-09-09 22:21:12', '2009-09-09 22:21:12'),
(2, 'invitado gerencia', 'Invitaciones de la casa', 100, '2009-09-09 22:22:15', '2009-09-09 22:22:15'),
(3, 'invitaciones Pxa', 'invitaciones de paxapoga. Por lo general se eberia utilizar para ocaciones de negocios.', 100, '2009-09-09 22:23:08', '2009-09-09 22:23:08');

-- --------------------------------------------------------

--
-- Table structure for table `detalle_comandas`
--

CREATE TABLE IF NOT EXISTS `detalle_comandas` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `producto_id` int(10) unsigned NOT NULL,
  `cant` tinyint(4) NOT NULL,
  `mesa_id` int(10) unsigned NOT NULL,
  `comanda_id` int(11) unsigned NOT NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `mesa_id` (`mesa_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `detalle_comandas`
--

INSERT INTO `detalle_comandas` (`id`, `producto_id`, `cant`, `mesa_id`, `comanda_id`, `created`, `modified`) VALUES
(1, 1, 2, 1, 1, '2009-09-09 02:13:08', '2009-09-09 02:13:08'),
(2, 2, 1, 1, 1, '2009-09-09 02:13:08', '2009-09-09 02:13:08'),
(3, 5, 1, 1, 2, '2009-09-09 02:13:29', '2009-09-09 02:13:29'),
(4, 4, 1, 1, 2, '2009-09-09 02:13:29', '2009-09-09 02:13:29'),
(5, 1, -1, 1, 0, '2009-09-09 02:23:13', '2009-09-09 02:23:13'),
(6, 1, -1, 1, 0, '2009-09-09 02:26:24', '2009-09-09 02:26:24'),
(7, 5, -1, 1, 0, '2009-09-09 02:40:06', '2009-09-09 02:40:06'),
(8, 5, 2, 2, 3, '2009-09-09 17:22:03', '2009-09-09 17:22:03');

-- --------------------------------------------------------

--
-- Table structure for table `mesas`
--

CREATE TABLE IF NOT EXISTS `mesas` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `numero` int(11) NOT NULL,
  `mozo_id` int(10) unsigned NOT NULL,
  `total` float(10,2) default '0.00',
  `cliente_id` int(10) unsigned default '0',
  `menu` tinyint(4) NOT NULL default '0' COMMENT 'es para cuando un cliente quiere imprimir el importe como MENU sin que se vea lo que consumio',
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  `time_cerro_mesa` timestamp NOT NULL default '0000-00-00 00:00:00',
  `time_cobro` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mesas`
--

INSERT INTO `mesas` (`id`, `numero`, `mozo_id`, `total`, `cliente_id`, `menu`, `created`, `modified`, `time_cerro_mesa`, `time_cobro`) VALUES
(1, 1, 3, NULL, NULL, 0, '2009-09-09 02:12:48', '2009-09-09 02:12:48', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 5, 3, NULL, NULL, 0, '2009-09-09 02:38:52', '2009-09-09 17:22:48', '2009-09-09 17:22:48', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `mozos`
--

CREATE TABLE IF NOT EXISTS `mozos` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user_id` int(10) unsigned NOT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `mozos`
--

INSERT INTO `mozos` (`id`, `user_id`, `numero`) VALUES
(1, 1, 10),
(2, 1, 11),
(3, 1, 1),
(4, 1, 2),
(5, 1, 3),
(6, 1, 4),
(7, 1, 5),
(8, 1, 6),
(9, 1, 7),
(10, 1, 8),
(11, 1, 16);

-- --------------------------------------------------------

--
-- Table structure for table `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `abrev` varchar(14) NOT NULL,
  `description` text NOT NULL,
  `categoria_id` int(10) unsigned NOT NULL,
  `precio` float(10,2) NOT NULL,
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `productos`
--

INSERT INTO `productos` (`id`, `name`, `abrev`, `description`, `categoria_id`, `precio`, `created`, `modified`) VALUES
(1, 'pepsi', 'pepsi', '', 4, 6.00, '2009-07-26 17:17:51', '2009-07-26 17:17:51'),
(2, '7up', '7up', '', 4, 6.00, '2009-07-26 17:19:11', '2009-07-26 17:19:11'),
(3, 'San Felipe Robles', 'S.Felipe.Roble', '', 5, 33.00, '2009-07-26 17:19:49', '2009-07-26 17:19:49'),
(4, 'Ensalada mixta', 'Ensalada mixta', '', 3, 11.00, '2009-07-26 17:20:12', '2009-07-26 17:20:12'),
(5, 'Melon c/jamon crud', 'melon.c/crudo', 'melosn con jamon crudo', 3, 8.00, '2009-07-26 17:20:59', '2009-07-26 17:20:59'),
(6, 'Paxa Mousse', 'Mousse', '', 6, 16.00, '2009-08-10 00:04:58', '2009-08-10 00:04:58'),
(7, 'TiramisÃº', 'tiramisÃº', '', 6, 16.00, '2009-08-31 01:07:39', '2009-08-31 01:07:39'),
(8, 'Asado', 'asado', '', 11, 30.00, '2009-08-31 17:59:47', '2009-08-31 17:59:47'),
(9, 'Chorizo', 'chorizo', '', 11, 20.00, '2009-08-31 18:00:11', '2009-08-31 18:00:11');

-- --------------------------------------------------------

--
-- Table structure for table `restaurantes`
--

CREATE TABLE IF NOT EXISTS `restaurantes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `restaurantes`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(64) NOT NULL default 'invitado',
  `nombre` varchar(40) NOT NULL,
  `apellido` varchar(40) NOT NULL,
  `telefono` varchar(20) default NULL,
  `domicilio` varchar(110) NOT NULL default '''''',
  `created` timestamp NULL default NULL,
  `modified` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `nombre`, `apellido`, `telefono`, `domicilio`, `created`, `modified`) VALUES
(1, 'alevilar', '8fb60eac807682911c163fe06a82988360a6c941', 'guest', 'alejandro', 'vilar', '45857291', '''''', NULL, NULL),
(2, 'pepe', 'a3c93d44750c431d5a0e48a17a6706a1cb2b7d0c', 'cliente', 'pepe ruiz', 'ramirez', '456456654', '''''', NULL, '2009-09-10 00:21:07'),
(4, 'manolo', '8c18f5466c2eafeb6630f4b1c9f9b45e7e53bce6', 'cliente', 'Manu manolo', 'Gomez', '', '''''', NULL, NULL),
(5, 'manolo2', '683e1f05e0982b2e4601a370349bb219d094b5be', 'cliente', 'Manu manolo', 'Gomez', '', '''''', NULL, NULL),
(6, 'maradona', '27515c964782e7985a6570913744a76c99a9cc21', 'cliente', 'Diego Armando', 'maradona', '', '''''', NULL, NULL),
(7, 'coppola', '2b6cb9fe7da448785c7d9a4aca9099f2955a923b', 'cliente', 'Guillote', 'Coppola', '', '''''', NULL, NULL);
